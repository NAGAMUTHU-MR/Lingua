import { useState, useEffect, useCallback, useRef } from 'react';

export interface Language {
  code: string;
  name: string;
  nativeName: string;
  voices: SpeechSynthesisVoice[];
}

export const useTextToSpeech = () => {
  const [isSupported, setIsSupported] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [availableLanguages, setAvailableLanguages] = useState<Language[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en-US');
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [rate, setRate] = useState(1.0);
  const [pitch, setPitch] = useState(1.0);
  const [volume, setVolume] = useState(1.0);
  
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Language mapping with native names
  const languageNames: Record<string, { name: string; nativeName: string }> = {
    'en': { name: 'English', nativeName: 'English' },
    'es': { name: 'Spanish', nativeName: 'Español' },
    'fr': { name: 'French', nativeName: 'Français' },
    'de': { name: 'German', nativeName: 'Deutsch' },
    'it': { name: 'Italian', nativeName: 'Italiano' },
    'pt': { name: 'Portuguese', nativeName: 'Português' },
    'ru': { name: 'Russian', nativeName: 'Русский' },
    'ja': { name: 'Japanese', nativeName: '日本語' },
    'ko': { name: 'Korean', nativeName: '한국어' },
    'zh': { name: 'Chinese', nativeName: '中文' },
    'ar': { name: 'Arabic', nativeName: 'العربية' },
    'hi': { name: 'Hindi', nativeName: 'हिन्दी' },
    'bn': { name: 'Bengali', nativeName: 'বাংলা' },
    'pa': { name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
    'te': { name: 'Telugu', nativeName: 'తెలుగు' },
    'mr': { name: 'Marathi', nativeName: 'मराठी' },
    'ta': { name: 'Tamil', nativeName: 'தமிழ்' },
    'ur': { name: 'Urdu', nativeName: 'اردو' },
    'gu': { name: 'Gujarati', nativeName: 'ગુજરાતી' },
    'kn': { name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
    'ml': { name: 'Malayalam', nativeName: 'മലയാളം' },
    'th': { name: 'Thai', nativeName: 'ไทย' },
    'vi': { name: 'Vietnamese', nativeName: 'Tiếng Việt' },
    'id': { name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
    'tr': { name: 'Turkish', nativeName: 'Türkçe' },
    'pl': { name: 'Polish', nativeName: 'Polski' },
    'uk': { name: 'Ukrainian', nativeName: 'Українська' },
    'nl': { name: 'Dutch', nativeName: 'Nederlands' },
    'sv': { name: 'Swedish', nativeName: 'Svenska' },
    'he': { name: 'Hebrew', nativeName: 'עברית' },
    'el': { name: 'Greek', nativeName: 'Ελληνικά' },
  };

  // Load available voices and languages
  const loadVoices = useCallback(() => {
    if (!window.speechSynthesis) return;

    const voices = window.speechSynthesis.getVoices();
    
    // Group voices by language
    const languageMap = new Map<string, SpeechSynthesisVoice[]>();
    
    voices.forEach(voice => {
      const langCode = voice.lang.split('-')[0];
      if (!languageMap.has(langCode)) {
        languageMap.set(langCode, []);
      }
      languageMap.get(langCode)?.push(voice);
    });

    // Create language objects
    const languages: Language[] = Array.from(languageMap.entries()).map(([code, voices]) => {
      const langInfo = languageNames[code] || { name: code, nativeName: code };
      return {
        code,
        name: langInfo.name,
        nativeName: langInfo.nativeName,
        voices,
      };
    }).sort((a, b) => a.name.localeCompare(b.name));

    setAvailableLanguages(languages);

    // Set default voice
    if (voices.length > 0 && !selectedVoice) {
      const defaultVoice = voices.find(v => v.lang.startsWith(selectedLanguage)) || voices[0];
      setSelectedVoice(defaultVoice);
    }
  }, [selectedLanguage, selectedVoice]);

  // Initialize speech synthesis
  useEffect(() => {
    if ('speechSynthesis' in window) {
      setIsSupported(true);
      loadVoices();

      // Chrome loads voices asynchronously
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    }

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [loadVoices]);

  // Speak text
  const speak = useCallback((text: string, options?: {
    language?: string;
    voice?: SpeechSynthesisVoice;
    rate?: number;
    pitch?: number;
    volume?: number;
    onEnd?: () => void;
    onError?: (error: SpeechSynthesisErrorEvent) => void;
  }) => {
    if (!isSupported || !text) return;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set voice
    const voice = options?.voice || selectedVoice;
    if (voice) {
      utterance.voice = voice;
    }

    // Set language
    utterance.lang = options?.language || selectedLanguage;
    
    // Set speech parameters
    utterance.rate = options?.rate ?? rate;
    utterance.pitch = options?.pitch ?? pitch;
    utterance.volume = options?.volume ?? volume;

    // Event handlers
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => {
      setIsSpeaking(false);
      options?.onEnd?.();
    };
    utterance.onerror = (event) => {
      setIsSpeaking(false);
      console.error('Speech synthesis error:', event);
      options?.onError?.(event);
    };

    utteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [isSupported, selectedVoice, selectedLanguage, rate, pitch, volume]);

  // Stop speaking
  const stop = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, []);

  // Pause speaking
  const pause = useCallback(() => {
    if (window.speechSynthesis && isSpeaking) {
      window.speechSynthesis.pause();
    }
  }, [isSpeaking]);

  // Resume speaking
  const resume = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.resume();
    }
  }, []);

  // Change language
  const changeLanguage = useCallback((langCode: string) => {
    setSelectedLanguage(langCode);
    
    // Find a voice for this language
    const language = availableLanguages.find(l => l.code === langCode.split('-')[0]);
    if (language && language.voices.length > 0) {
      setSelectedVoice(language.voices[0]);
    }
  }, [availableLanguages]);

  // Get voices for a specific language
  const getVoicesForLanguage = useCallback((langCode: string): SpeechSynthesisVoice[] => {
    const language = availableLanguages.find(l => l.code === langCode);
    return language?.voices || [];
  }, [availableLanguages]);

  return {
    isSupported,
    isSpeaking,
    availableLanguages,
    selectedLanguage,
    selectedVoice,
    rate,
    pitch,
    volume,
    speak,
    stop,
    pause,
    resume,
    setRate,
    setPitch,
    setVolume,
    setSelectedVoice,
    changeLanguage,
    getVoicesForLanguage,
  };
};
