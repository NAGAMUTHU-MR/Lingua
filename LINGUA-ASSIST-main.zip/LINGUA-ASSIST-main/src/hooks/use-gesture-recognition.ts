import { useState, useEffect, useRef, useCallback } from 'react';
import * as handPoseDetection from '@tensorflow-models/hand-pose-detection';
import * as tf from '@tensorflow/tfjs-core';
import '@tensorflow/tfjs-backend-webgl';

export type GestureType = 'thumbs_up' | 'thumbs_down' | 'peace' | 'fist' | 'open_palm' | 'pointing' | 'none';

interface GestureResult {
  gesture: GestureType;
  confidence: number;
}

export const useGestureRecognition = () => {
  const [isActive, setIsActive] = useState(false);
  const [currentGesture, setCurrentGesture] = useState<GestureResult>({ gesture: 'none', confidence: 0 });
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const detectorRef = useRef<handPoseDetection.HandDetector | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Initialize TensorFlow and load the hand pose model
  const initializeModel = useCallback(async () => {
    try {
      setIsModelLoading(true);
      setError(null);

      // Initialize TensorFlow backend
      await tf.ready();
      await tf.setBackend('webgl');

      // Create detector
      const model = handPoseDetection.SupportedModels.MediaPipeHands;
      const detectorConfig: handPoseDetection.MediaPipeHandsMediaPipeModelConfig = {
        runtime: 'mediapipe',
        solutionPath: 'https://cdn.jsdelivr.net/npm/@mediapipe/hands',
        maxHands: 1,
        modelType: 'full'
      };

      detectorRef.current = await handPoseDetection.createDetector(model, detectorConfig);
      setIsModelLoading(false);
    } catch (err) {
      console.error('Error initializing gesture recognition:', err);
      setError('Failed to initialize gesture recognition model');
      setIsModelLoading(false);
    }
  }, []);

  // Analyze hand landmarks to detect gestures
  const analyzeGesture = useCallback((hands: handPoseDetection.Hand[]): GestureResult => {
    if (!hands || hands.length === 0) {
      return { gesture: 'none', confidence: 0 };
    }

    const hand = hands[0];
    const keypoints = hand.keypoints;

    // Get key landmark positions
    const thumb_tip = keypoints[4];
    const thumb_ip = keypoints[3];
    const index_tip = keypoints[8];
    const index_mcp = keypoints[5];
    const middle_tip = keypoints[12];
    const middle_mcp = keypoints[9];
    const ring_tip = keypoints[16];
    const ring_mcp = keypoints[13];
    const pinky_tip = keypoints[20];
    const pinky_mcp = keypoints[17];
    const wrist = keypoints[0];

    // Helper function to check if finger is extended
    const isFingerExtended = (tip: any, mcp: any, wrist: any) => {
      const tipToWrist = Math.abs(tip.y - wrist.y);
      const mcpToWrist = Math.abs(mcp.y - wrist.y);
      return tipToWrist > mcpToWrist * 1.2;
    };

    // Count extended fingers
    const indexExtended = isFingerExtended(index_tip, index_mcp, wrist);
    const middleExtended = isFingerExtended(middle_tip, middle_mcp, wrist);
    const ringExtended = isFingerExtended(ring_tip, ring_mcp, wrist);
    const pinkyExtended = isFingerExtended(pinky_tip, pinky_mcp, wrist);
    const thumbExtended = thumb_tip.x > thumb_ip.x + 20 || thumb_tip.x < thumb_ip.x - 20;

    const extendedCount = [indexExtended, middleExtended, ringExtended, pinkyExtended, thumbExtended].filter(Boolean).length;

    // Detect specific gestures
    // Open Palm - all fingers extended
    if (extendedCount === 5) {
      return { gesture: 'open_palm', confidence: 0.9 };
    }

    // Peace sign - index and middle extended
    if (indexExtended && middleExtended && !ringExtended && !pinkyExtended) {
      return { gesture: 'peace', confidence: 0.85 };
    }

    // Pointing - only index extended
    if (indexExtended && !middleExtended && !ringExtended && !pinkyExtended) {
      return { gesture: 'pointing', confidence: 0.85 };
    }

    // Fist - no fingers extended
    if (extendedCount === 0) {
      return { gesture: 'fist', confidence: 0.9 };
    }

    // Thumbs up - thumb extended, others closed
    if (thumbExtended && thumb_tip.y < wrist.y && !indexExtended && !middleExtended) {
      return { gesture: 'thumbs_up', confidence: 0.8 };
    }

    // Thumbs down - thumb extended pointing down
    if (thumbExtended && thumb_tip.y > wrist.y && !indexExtended && !middleExtended) {
      return { gesture: 'thumbs_down', confidence: 0.8 };
    }

    return { gesture: 'none', confidence: 0 };
  }, []);

  // Detect gestures from video stream
  const detectGestures = useCallback(async () => {
    if (!detectorRef.current || !videoRef.current || !isActive) {
      return;
    }

    try {
      const hands = await detectorRef.current.estimateHands(videoRef.current);
      const gestureResult = analyzeGesture(hands);
      
      if (gestureResult.confidence > 0.7) {
        setCurrentGesture(gestureResult);
      }
    } catch (err) {
      console.error('Error detecting gestures:', err);
    }

    if (isActive) {
      animationFrameRef.current = requestAnimationFrame(detectGestures);
    }
  }, [isActive, analyzeGesture]);

  // Start gesture recognition
  const startGestureRecognition = useCallback(async () => {
    try {
      setError(null);

      // Initialize model if not already loaded
      if (!detectorRef.current) {
        await initializeModel();
      }

      // Get video stream
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 }
      });

      streamRef.current = stream;

      // Create video element if it doesn't exist
      if (!videoRef.current) {
        videoRef.current = document.createElement('video');
        videoRef.current.autoplay = true;
        videoRef.current.playsInline = true;
      }

      videoRef.current.srcObject = stream;
      await videoRef.current.play();

      setIsActive(true);
    } catch (err) {
      console.error('Error starting gesture recognition:', err);
      setError('Failed to access camera. Please grant camera permissions.');
    }
  }, [initializeModel]);

  // Stop gesture recognition
  const stopGestureRecognition = useCallback(() => {
    setIsActive(false);

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setCurrentGesture({ gesture: 'none', confidence: 0 });
  }, []);

  // Start detection loop when active
  useEffect(() => {
    if (isActive && detectorRef.current && videoRef.current) {
      detectGestures();
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isActive, detectGestures]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopGestureRecognition();
      if (detectorRef.current) {
        detectorRef.current.dispose();
      }
    };
  }, [stopGestureRecognition]);

  return {
    isActive,
    currentGesture,
    isModelLoading,
    error,
    startGestureRecognition,
    stopGestureRecognition,
    videoElement: videoRef.current,
  };
};
