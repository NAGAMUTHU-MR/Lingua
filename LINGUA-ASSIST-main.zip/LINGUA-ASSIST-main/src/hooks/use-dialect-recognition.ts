import { useState, useCallback, useRef } from 'react';
import { HfInference } from '@huggingface/inference';
import { DialectConfig, SUPPORTED_DIALECTS } from '@/config/dialects';

interface RecognitionResult {
  text: string;
  confidence?: number;
  dialect: string;
}

export const useDialectRecognition = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [selectedDialect, setSelectedDialect] = useState<DialectConfig>(SUPPORTED_DIALECTS[0]);
  const [error, setError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<RecognitionResult | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const hfRef = useRef<HfInference | null>(null);

  // Initialize Hugging Face client
  const initializeHF = useCallback(() => {
    if (!hfRef.current) {
      const apiKey = import.meta.env.VITE_HUGGINGFACE_API_KEY;
      if (!apiKey) {
        setError('Hugging Face API key not found. Please add VITE_HUGGINGFACE_API_KEY to your .env file');
        return false;
      }
      hfRef.current = new HfInference(apiKey);
    }
    return true;
  }, []);

  // Start recording audio
  const startRecording = useCallback(async () => {
    try {
      setError(null);
      audioChunksRef.current = [];

      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        } 
      });

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        await recognizeDialect(audioBlob);
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Error starting recording:', err);
      setError('Failed to access microphone. Please grant microphone permissions.');
    }
  }, []);

  // Stop recording audio
  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }, [isRecording]);

  // Recognize dialect from audio blob
  const recognizeDialect = useCallback(async (audioBlob: Blob): Promise<string | null> => {
    if (!initializeHF()) {
      return null;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // Convert blob to array buffer
      const arrayBuffer = await audioBlob.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);

      // Use Hugging Face Inference API
      const result = await hfRef.current!.automaticSpeechRecognition({
        model: selectedDialect.model,
        data: uint8Array
      });

      const recognizedText = result.text || '';
      
      const recognitionResult: RecognitionResult = {
        text: recognizedText,
        dialect: selectedDialect.code,
        confidence: 0.8 // HF API doesn't return confidence, using default
      };

      setLastResult(recognitionResult);
      setIsProcessing(false);
      
      return recognizedText;
    } catch (err: any) {
      console.error('Dialect recognition error:', err);
      
      let errorMessage = 'Failed to recognize dialect';
      if (err.message?.includes('API key')) {
        errorMessage = 'Invalid Hugging Face API key';
      } else if (err.message?.includes('rate limit')) {
        errorMessage = 'Rate limit exceeded. Please try again later.';
      } else if (err.message?.includes('model')) {
        errorMessage = 'Model not available. Using fallback.';
      }
      
      setError(errorMessage);
      setIsProcessing(false);
      return null;
    }
  }, [selectedDialect, initializeHF]);

  // Recognize from file upload
  const recognizeFromFile = useCallback(async (file: File): Promise<string | null> => {
    if (!file.type.startsWith('audio/')) {
      setError('Please upload an audio file');
      return null;
    }

    return await recognizeDialect(file);
  }, [recognizeDialect]);

  // Change selected dialect
  const changeDialect = useCallback((dialect: DialectConfig) => {
    setSelectedDialect(dialect);
    setError(null);
    setLastResult(null);
  }, []);

  // Get dialects by language
  const getDialectsByLanguage = useCallback((languageCode: string): DialectConfig[] => {
    return SUPPORTED_DIALECTS.filter(d => d.languageCode === languageCode);
  }, []);

  // Clear error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Clear last result
  const clearResult = useCallback(() => {
    setLastResult(null);
  }, []);

  return {
    // State
    isProcessing,
    isRecording,
    selectedDialect,
    availableDialects: SUPPORTED_DIALECTS,
    error,
    lastResult,
    
    // Actions
    startRecording,
    stopRecording,
    recognizeDialect,
    recognizeFromFile,
    changeDialect,
    getDialectsByLanguage,
    clearError,
    clearResult,
  };
};
