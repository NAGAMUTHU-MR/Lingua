import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { DialectConfig } from "@/config/dialects";

interface DialectSelectorProps {
  selectedDialect: DialectConfig;
  onDialectChange: (dialect: DialectConfig) => void;
  availableDialects: DialectConfig[];
  disabled?: boolean;
}

export const DialectSelector = ({
  selectedDialect,
  onDialectChange,
  availableDialects,
  disabled = false,
}: DialectSelectorProps) => {
  // Group dialects by language
  const groupedDialects = availableDialects.reduce((acc, dialect) => {
    if (!acc[dialect.language]) {
      acc[dialect.language] = [];
    }
    acc[dialect.language].push(dialect);
    return acc;
  }, {} as Record<string, DialectConfig[]>);

  // Sort languages alphabetically
  const sortedLanguages = Object.keys(groupedDialects).sort();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2"
          disabled={disabled}
        >
          <Languages className="h-4 w-4" />
          <span className="hidden sm:inline">{selectedDialect.nativeName}</span>
          <span className="sm:hidden">{selectedDialect.languageCode.toUpperCase()}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72 max-h-96 overflow-y-auto">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>Select Dialect</span>
          <Badge variant="secondary" className="text-xs">
            {availableDialects.length} dialects
          </Badge>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {sortedLanguages.map((language) => (
          <div key={language}>
            <DropdownMenuLabel className="text-xs text-muted-foreground font-semibold">
              {language}
            </DropdownMenuLabel>
            {groupedDialects[language].map((dialect) => (
              <DropdownMenuItem
                key={dialect.code}
                onClick={() => onDialectChange(dialect)}
                className="flex flex-col items-start py-2 cursor-pointer"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex flex-col">
                    <span className="font-medium">{dialect.nativeName}</span>
                    <span className="text-xs text-muted-foreground">
                      {dialect.name}
                    </span>
                  </div>
                  {selectedDialect.code === dialect.code && (
                    <Badge variant="default" className="ml-2">Active</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-muted-foreground">
                    {dialect.region}
                  </span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-xs text-muted-foreground">
                    {(dialect.speakers / 1000000).toFixed(0)}M speakers
                  </span>
                </div>
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
          </div>
        ))}
        
        <div className="p-2 text-xs text-muted-foreground text-center">
          Powered by AI4Bharat
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
