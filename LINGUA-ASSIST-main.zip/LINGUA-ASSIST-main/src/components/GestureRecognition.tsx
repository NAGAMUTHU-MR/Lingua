import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Hand, HandMetal, ThumbsUp, ThumbsDown, Loader2, X } from "lucide-react";
import { useGestureRecognition, GestureType } from "@/hooks/use-gesture-recognition";
import { Badge } from "@/components/ui/badge";

interface GestureRecognitionProps {
  onGestureDetected?: (gesture: GestureType) => void;
  onClose?: () => void;
}

const gestureIcons: Record<GestureType, React.ReactNode> = {
  thumbs_up: <ThumbsUp className="h-8 w-8" />,
  thumbs_down: <ThumbsDown className="h-8 w-8" />,
  peace: <HandMetal className="h-8 w-8" />,
  fist: <Hand className="h-8 w-8" />,
  open_palm: <Hand className="h-8 w-8" />,
  pointing: <Hand className="h-8 w-8" />,
  none: <Hand className="h-8 w-8 opacity-30" />,
};

const gestureLabels: Record<GestureType, string> = {
  thumbs_up: "Thumbs Up",
  thumbs_down: "Thumbs Down",
  peace: "Peace Sign",
  fist: "Fist",
  open_palm: "Open Palm",
  pointing: "Pointing",
  none: "No gesture detected",
};

export const GestureRecognition = ({ onGestureDetected, onClose }: GestureRecognitionProps) => {
  const {
    isActive,
    currentGesture,
    isModelLoading,
    error,
    startGestureRecognition,
    stopGestureRecognition,
    videoElement,
  } = useGestureRecognition();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previousGestureRef = useRef<GestureType>('none');

  // Start recognition on mount
  useEffect(() => {
    startGestureRecognition();
    return () => stopGestureRecognition();
  }, [startGestureRecognition, stopGestureRecognition]);

  // Call callback when gesture changes
  useEffect(() => {
    if (
      currentGesture.gesture !== 'none' &&
      currentGesture.gesture !== previousGestureRef.current &&
      currentGesture.confidence > 0.7
    ) {
      onGestureDetected?.(currentGesture.gesture);
      previousGestureRef.current = currentGesture.gesture;
    }

    // Reset previous gesture after a delay
    const timeout = setTimeout(() => {
      if (currentGesture.gesture === 'none') {
        previousGestureRef.current = 'none';
      }
    }, 1000);

    return () => clearTimeout(timeout);
  }, [currentGesture, onGestureDetected]);

  // Draw video feed to canvas
  useEffect(() => {
    if (!videoElement || !canvasRef.current || !isActive) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const drawFrame = () => {
      if (videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
        canvas.width = videoElement.videoWidth;
        canvas.height = videoElement.videoHeight;
        
        // Mirror the video horizontally for better UX
        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(videoElement, -canvas.width, 0, canvas.width, canvas.height);
        ctx.restore();
      }
      
      if (isActive) {
        requestAnimationFrame(drawFrame);
      }
    };

    drawFrame();
  }, [videoElement, isActive]);

  const handleClose = () => {
    stopGestureRecognition();
    onClose?.();
  };

  return (
    <Card className="relative overflow-hidden gradient-card border-border/50">
      <div className="absolute top-2 right-2 z-10">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleClose}
          className="bg-background/80 backdrop-blur-sm"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Hand className="h-5 w-5" />
            Gesture Recognition
          </h3>
          {isActive && (
            <Badge variant="secondary" className="animate-pulse">
              Active
            </Badge>
          )}
        </div>

        {error && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {isModelLoading && (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Loading gesture recognition model...</span>
          </div>
        )}

        {!isModelLoading && !error && (
          <>
            {/* Video Feed */}
            <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
              <canvas
                ref={canvasRef}
                className="w-full h-full object-cover"
              />
              
              {/* Gesture Overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between bg-background/80 backdrop-blur-sm p-3 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="text-primary">
                    {gestureIcons[currentGesture.gesture]}
                  </div>
                  <div>
                    <p className="font-semibold text-sm">
                      {gestureLabels[currentGesture.gesture]}
                    </p>
                    {currentGesture.confidence > 0 && (
                      <p className="text-xs text-muted-foreground">
                        Confidence: {Math.round(currentGesture.confidence * 100)}%
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Instructions */}
            <div className="text-sm text-muted-foreground space-y-1">
              <p className="font-semibold">Supported Gestures:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>👍 Thumbs Up - Show approval</li>
                <li>👎 Thumbs Down - Show disapproval</li>
                <li>✌️ Peace Sign - Two fingers up</li>
                <li>👉 Pointing - Index finger extended</li>
                <li>✋ Open Palm - All fingers extended</li>
                <li>✊ Fist - All fingers closed</li>
              </ul>
            </div>
          </>
        )}
      </div>
    </Card>
  );
};
