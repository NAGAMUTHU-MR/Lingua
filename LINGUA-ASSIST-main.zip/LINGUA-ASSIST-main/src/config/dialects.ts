export interface DialectConfig {
  code: string;
  name: string;
  nativeName: string;
  language: string;
  languageCode: string;
  model: string;
  region: string;
  speakers: number; // estimated speakers
}

export const SUPPORTED_DIALECTS: DialectConfig[] = [
  // Tamil Dialects
  {
    code: 'ta-kongu',
    name: 'Kongu Tamil',
    nativeName: 'கொங்கு தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Western Tamil Nadu',
    speakers: 10000000
  },
  {
    code: 'ta-chennai',
    name: 'Chennai Tamil',
    nativeName: 'சென்னை தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Chennai & surroundings',
    speakers: 15000000
  },
  {
    code: 'ta-madurai',
    name: 'Madurai Tamil',
    nativeName: 'மதுரை தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Southern Tamil Nadu',
    speakers: 8000000
  },
  {
    code: 'ta-standard',
    name: 'Standard Tamil',
    nativeName: 'தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Tamil Nadu',
    speakers: 75000000
  },
  
  // Hindi Dialects
  {
    code: 'hi-standard',
    name: 'Standard Hindi',
    nativeName: 'हिन्दी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'North India',
    speakers: 600000000
  },
  {
    code: 'hi-bhojpuri',
    name: 'Bhojpuri',
    nativeName: 'भोजपुरी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'Bihar, UP, Jharkhand',
    speakers: 50000000
  },
  {
    code: 'hi-haryanvi',
    name: 'Haryanvi',
    nativeName: 'हरियाणवी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'Haryana',
    speakers: 20000000
  },
  {
    code: 'hi-rajasthani',
    name: 'Rajasthani',
    nativeName: 'राजस्थानी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'Rajasthan',
    speakers: 25000000
  },
  
  // Telugu Dialects
  {
    code: 'te-standard',
    name: 'Standard Telugu',
    nativeName: 'తెలుగు',
    language: 'Telugu',
    languageCode: 'te',
    model: 'ai4bharat/indicwav2vec-telugu',
    region: 'Andhra Pradesh, Telangana',
    speakers: 80000000
  },
  {
    code: 'te-coastal',
    name: 'Coastal Telugu',
    nativeName: 'తీర తెలుగు',
    language: 'Telugu',
    languageCode: 'te',
    model: 'ai4bharat/indicwav2vec-telugu',
    region: 'Coastal Andhra',
    speakers: 20000000
  },
  
  // Bengali Dialects
  {
    code: 'bn-standard',
    name: 'Standard Bengali',
    nativeName: 'বাংলা',
    language: 'Bengali',
    languageCode: 'bn',
    model: 'ai4bharat/indicwav2vec-bengali',
    region: 'West Bengal, Bangladesh',
    speakers: 230000000
  },
  {
    code: 'bn-sylheti',
    name: 'Sylheti',
    nativeName: 'সিলেটি',
    language: 'Bengali',
    languageCode: 'bn',
    model: 'ai4bharat/indicwav2vec-bengali',
    region: 'Sylhet region',
    speakers: 10000000
  },
  
  // Marathi Dialects
  {
    code: 'mr-standard',
    name: 'Standard Marathi',
    nativeName: 'मराठी',
    language: 'Marathi',
    languageCode: 'mr',
    model: 'ai4bharat/indicwav2vec-marathi',
    region: 'Maharashtra',
    speakers: 83000000
  },
  
  // Gujarati Dialects
  {
    code: 'gu-standard',
    name: 'Standard Gujarati',
    nativeName: 'ગુજરાતી',
    language: 'Gujarati',
    languageCode: 'gu',
    model: 'ai4bharat/indicwav2vec-gujarati',
    region: 'Gujarat',
    speakers: 55000000
  },
  
  // Kannada Dialects
  {
    code: 'kn-standard',
    name: 'Standard Kannada',
    nativeName: 'ಕನ್ನಡ',
    language: 'Kannada',
    languageCode: 'kn',
    model: 'ai4bharat/indicwav2vec-kannada',
    region: 'Karnataka',
    speakers: 44000000
  },
  
  // Malayalam Dialects
  {
    code: 'ml-standard',
    name: 'Standard Malayalam',
    nativeName: 'മലയാളം',
    language: 'Malayalam',
    languageCode: 'ml',
    model: 'ai4bharat/indicwav2vec-malayalam',
    region: 'Kerala',
    speakers: 38000000
  },
  
  // Punjabi Dialects
  {
    code: 'pa-standard',
    name: 'Standard Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    language: 'Punjabi',
    languageCode: 'pa',
    model: 'ai4bharat/indicwav2vec-punjabi',
    region: 'Punjab',
    speakers: 125000000
  },
  
  // Odia
  {
    code: 'or-standard',
    name: 'Standard Odia',
    nativeName: 'ଓଡ଼ିଆ',
    language: 'Odia',
    languageCode: 'or',
    model: 'ai4bharat/indicwav2vec-odia',
    region: 'Odisha',
    speakers: 35000000
  },
];

// Helper function to get dialects by language
export const getDialectsByLanguage = (languageCode: string): DialectConfig[] => {
  return SUPPORTED_DIALECTS.filter(d => d.languageCode === languageCode);
};

// Helper function to get dialect by code
export const getDialectByCode = (code: string): DialectConfig | undefined => {
  return SUPPORTED_DIALECTS.find(d => d.code === code);
};

// Helper function to get all unique languages
export const getUniqueLanguages = (): string[] => {
  return Array.from(new Set(SUPPORTED_DIALECTS.map(d => d.language)));
};
