import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Award,
  TrendingUp,
  MessageSquare,
  ThumbsUp,
  Star,
  Trophy,
  Target,
  Zap,
} from "lucide-react";

interface Profile {
  id: string;
  username: string;
  points: number;
  level: number;
  contributions: number;
  verified_phrases: number;
  created_at: string;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned_at: string;
}

interface Achievement {
  name: string;
  description: string;
  icon: React.ReactNode;
  progress: number;
  total: number;
  earned: boolean;
}

const Profile = () => {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        navigate("/auth");
        return;
      }

      setUser(session.user);

      // Load profile data
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", session.user.id)
        .single();

      if (profileError) throw profileError;
      setProfile(profileData);

      // Load badges
      const { data: badgesData, error: badgesError } = await supabase
        .from("user_badges")
        .select("*, badges(*)")
        .eq("user_id", session.user.id);

      if (badgesError) throw badgesError;
      setBadges(badgesData?.map((ub: any) => ({
        id: ub.badges.id,
        name: ub.badges.name,
        description: ub.badges.description,
        icon: ub.badges.icon,
        earned_at: ub.earned_at,
      })) || []);

    } catch (error: any) {
      toast({
        title: "Error loading profile",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getAchievements = (): Achievement[] => {
    if (!profile) return [];

    return [
      {
        name: "First Contribution",
        description: "Submit your first phrase",
        icon: <MessageSquare className="h-6 w-6" />,
        progress: Math.min(profile.contributions, 1),
        total: 1,
        earned: profile.contributions >= 1,
      },
      {
        name: "Community Helper",
        description: "Submit 10 phrases",
        icon: <ThumbsUp className="h-6 w-6" />,
        progress: Math.min(profile.contributions, 10),
        total: 10,
        earned: profile.contributions >= 10,
      },
      {
        name: "Language Expert",
        description: "Submit 50 phrases",
        icon: <Star className="h-6 w-6" />,
        progress: Math.min(profile.contributions, 50),
        total: 50,
        earned: profile.contributions >= 50,
      },
      {
        name: "Verification Master",
        description: "Get 25 phrases verified",
        icon: <Trophy className="h-6 w-6" />,
        progress: Math.min(profile.verified_phrases, 25),
        total: 25,
        earned: profile.verified_phrases >= 25,
      },
      {
        name: "Point Collector",
        description: "Earn 1000 points",
        icon: <Target className="h-6 w-6" />,
        progress: Math.min(profile.points, 1000),
        total: 1000,
        earned: profile.points >= 1000,
      },
      {
        name: "Level 10",
        description: "Reach level 10",
        icon: <Zap className="h-6 w-6" />,
        progress: Math.min(profile.level, 10),
        total: 10,
        earned: profile.level >= 10,
      },
    ];
  };

  const getLevelProgress = () => {
    if (!profile) return 0;
    const pointsForNextLevel = profile.level * 100;
    const pointsInCurrentLevel = profile.points % 100;
    return (pointsInCurrentLevel / pointsForNextLevel) * 100;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-6">
          <p className="text-muted-foreground">Profile not found</p>
          <Button onClick={() => navigate("/")} className="mt-4">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  const achievements = getAchievements();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Profile</h1>
              <p className="text-sm text-muted-foreground">Your achievements and progress</p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Profile Card */}
          <div className="md:col-span-1">
            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader className="text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarFallback className="text-2xl gradient-accent">
                    {profile.username?.charAt(0).toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <CardTitle className="text-2xl">{profile.username || "User"}</CardTitle>
                <CardDescription className="flex items-center justify-center gap-2 mt-2">
                  <Award className="h-4 w-4" />
                  Level {profile.level}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Level Progress</span>
                    <span className="font-semibold">{profile.points % 100} / {profile.level * 100}</span>
                  </div>
                  <Progress value={getLevelProgress()} className="h-2" />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="text-center p-3 bg-primary/10 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{profile.points}</p>
                    <p className="text-xs text-muted-foreground">Total Points</p>
                  </div>
                  <div className="text-center p-3 bg-secondary/10 rounded-lg">
                    <p className="text-2xl font-bold text-secondary">{profile.contributions}</p>
                    <p className="text-xs text-muted-foreground">Contributions</p>
                  </div>
                  <div className="text-center p-3 bg-accent/10 rounded-lg">
                    <p className="text-2xl font-bold text-accent">{profile.verified_phrases}</p>
                    <p className="text-xs text-muted-foreground">Verified</p>
                  </div>
                  <div className="text-center p-3 bg-primary/10 rounded-lg">
                    <p className="text-2xl font-bold text-primary">{badges.length}</p>
                    <p className="text-xs text-muted-foreground">Badges</p>
                  </div>
                </div>

                <Button className="w-full" onClick={() => navigate("/community")}>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Contribute More
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Achievements and Badges */}
          <div className="md:col-span-2 space-y-6">
            {/* Achievements */}
            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  Achievements
                </CardTitle>
                <CardDescription>Track your progress and unlock rewards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {achievements.map((achievement, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border ${
                        achievement.earned
                          ? "bg-primary/10 border-primary/20"
                          : "bg-muted/50 border-border"
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={achievement.earned ? "text-primary" : "text-muted-foreground"}>
                          {achievement.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm mb-1">{achievement.name}</h4>
                          <p className="text-xs text-muted-foreground mb-2">
                            {achievement.description}
                          </p>
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">
                                {achievement.progress} / {achievement.total}
                              </span>
                              <span className="font-semibold">
                                {Math.round((achievement.progress / achievement.total) * 100)}%
                              </span>
                            </div>
                            <Progress
                              value={(achievement.progress / achievement.total) * 100}
                              className="h-1"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Badges */}
            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Earned Badges
                </CardTitle>
                <CardDescription>
                  {badges.length > 0
                    ? `You've earned ${badges.length} badge${badges.length !== 1 ? "s" : ""}`
                    : "Start contributing to earn badges"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {badges.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {badges.map((badge) => (
                      <div
                        key={badge.id}
                        className="p-4 text-center rounded-lg bg-gradient-to-br from-primary/20 to-secondary/20 border border-border hover:shadow-glow transition-all"
                      >
                        <div className="text-4xl mb-2">{badge.icon}</div>
                        <h4 className="font-semibold text-sm mb-1">{badge.name}</h4>
                        <p className="text-xs text-muted-foreground">{badge.description}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Award className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No badges earned yet</p>
                    <p className="text-sm mt-1">Keep contributing to unlock badges!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
