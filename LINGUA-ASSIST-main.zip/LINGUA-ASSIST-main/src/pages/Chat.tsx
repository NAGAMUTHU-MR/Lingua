import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Mic, MicOff, Send, LogOut, User, Hand, Volume2, VolumeX } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { GestureRecognition } from "@/components/GestureRecognition";
import { LanguageSelector } from "@/components/LanguageSelector";
import { useTextToSpeech } from "@/hooks/use-text-to-speech";
import { GestureType } from "@/hooks/use-gesture-recognition";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [showGesture, setShowGesture] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const recognitionRef = useRef<any>(null);
  const { speak, stop: stopSpeaking, isSpeaking, selectedLanguage, changeLanguage } = useTextToSpeech();

  useEffect(() => {
    // Check authentication
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session?.user);
      }
    });

    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setListening(false);
      };

      recognitionRef.current.onerror = () => {
        setListening(false);
        toast({
          title: "Speech recognition error",
          description: "Please try again",
          variant: "destructive",
        });
      };

      recognitionRef.current.onend = () => {
        setListening(false);
      };
    }

    return () => subscription.unsubscribe();
  }, [navigate, toast]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const toggleListening = () => {
    if (listening) {
      recognitionRef.current?.stop();
    } else {
      try {
        recognitionRef.current?.start();
        setListening(true);
      } catch (error) {
        toast({
          title: "Microphone access required",
          description: "Please allow microphone access to use voice input",
          variant: "destructive",
        });
      }
    }
  };

  const sendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: Message = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("chat", {
        body: { messages: [...messages, userMessage] },
      });

      if (error) throw error;

      const assistantMessage: Message = {
        role: "assistant",
        content: data.choices[0].message.content,
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Speak the response if TTS is enabled
      if (ttsEnabled) {
        speak(assistantMessage.content);
      }

      // Save messages to database
      await supabase.from("chat_messages").insert([
        { user_id: user.id, role: "user", content: userMessage.content },
        { user_id: user.id, role: "assistant", content: assistantMessage.content },
      ]);

    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to send message",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleGestureDetected = (gesture: GestureType) => {
    toast({
      title: "Gesture Detected",
      description: `You made a ${gesture.replace('_', ' ')} gesture!`,
    });

    // Map gestures to actions
    switch (gesture) {
      case 'thumbs_up':
        setInput('👍 I agree!');
        break;
      case 'thumbs_down':
        setInput('👎 I disagree.');
        break;
      case 'peace':
        setInput('✌️ Peace!');
        break;
      case 'open_palm':
        setInput('👋 Hello!');
        break;
      case 'pointing':
        setInput('👉 That one!');
        break;
      case 'fist':
        setInput('✊ Yes!');
        break;
    }
  };

  const toggleTTS = () => {
    if (isSpeaking) {
      stopSpeaking();
    }
    setTtsEnabled(!ttsEnabled);
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full gradient-accent" />
            <div>
              <h1 className="text-xl font-bold">AI Assistant</h1>
              <p className="text-sm text-muted-foreground">Here to help</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <LanguageSelector
              selectedLanguage={selectedLanguage}
              onLanguageChange={changeLanguage}
            />
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTTS}
              title={ttsEnabled ? "Disable Text-to-Speech" : "Enable Text-to-Speech"}
            >
              {ttsEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowGesture(!showGesture)}
              title="Toggle Gesture Recognition"
            >
              <Hand className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/community")}>
              Community
            </Button>
            <Button variant="ghost" size="icon" onClick={handleSignOut}>
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div className="container mx-auto max-w-3xl">
          {/* Gesture Recognition Panel */}
          {showGesture && (
            <div className="mb-4">
              <GestureRecognition
                onGestureDetected={handleGestureDetected}
                onClose={() => setShowGesture(false)}
              />
            </div>
          )}
          {messages.length === 0 && (
            <Card className="p-8 text-center gradient-card border-border/50">
              <h2 className="text-2xl font-bold mb-2">Welcome!</h2>
              <p className="text-muted-foreground">
                Start a conversation or use voice input to communicate
              </p>
            </Card>
          )}

          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex gap-3 ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              {message.role === "assistant" && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="gradient-accent text-xs">AI</AvatarFallback>
                </Avatar>
              )}
              <Card
                className={`max-w-[80%] p-4 ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "gradient-card border-border/50"
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
              </Card>
              {message.role === "user" && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-secondary text-xs">
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="gradient-accent text-xs">AI</AvatarFallback>
              </Avatar>
              <Card className="p-4 gradient-card border-border/50">
                <Loader2 className="h-5 w-5 animate-spin" />
              </Card>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card/50 backdrop-blur-sm p-4">
        <form onSubmit={sendMessage} className="container mx-auto max-w-3xl">
          <div className="flex gap-2">
            <Button
              type="button"
              size="icon"
              variant={listening ? "default" : "outline"}
              onClick={toggleListening}
              disabled={!recognitionRef.current}
            >
              {listening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </Button>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message or use voice..."
              disabled={loading}
              className="flex-1"
            />
            <Button type="submit" disabled={loading || !input.trim()}>
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Chat;
