import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp, ThumbsDown, ArrowLeft, Plus, Award, Users, Trophy, User as UserIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Phrase {
  id: string;
  phrase: string;
  translation: string;
  language_code: string;
  dialect: string;
  category: string;
  verified: boolean;
  vote_count: number;
  created_at: string;
}

const Community = () => {
  const [phrases, setPhrases] = useState<Phrase[]>([]);
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [newPhrase, setNewPhrase] = useState({
    phrase: "",
    translation: "",
    language_code: "en",
    dialect: "",
    category: "",
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setUser(session.user);
        loadProfile(session.user.id);
      }
    });

    loadPhrases();
  }, []);

  const loadProfile = async (userId: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();
    
    if (data) setProfile(data);
  };

  const loadPhrases = async () => {
    const { data, error } = await supabase
      .from("dialect_phrases")
      .select("*")
      .order("vote_count", { ascending: false })
      .limit(20);

    if (error) {
      toast({
        title: "Error loading phrases",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setPhrases(data || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { error } = await supabase.from("dialect_phrases").insert([
      { ...newPhrase, user_id: user.id },
    ]);

    if (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Success! 🎉",
        description: "Your phrase has been submitted for review.",
      });
      setShowForm(false);
      setNewPhrase({
        phrase: "",
        translation: "",
        language_code: "en",
        dialect: "",
        category: "",
      });
      loadPhrases();
    }
  };

  const handleVote = async (phraseId: string, voteType: "up" | "down") => {
    if (!user) {
      navigate("/auth");
      return;
    }

    const { error } = await supabase.from("phrase_votes").upsert([
      { phrase_id: phraseId, user_id: user.id, vote_type: voteType },
    ]);

    if (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } else {
      loadPhrases();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Community Phrases</h1>
                <p className="text-sm text-muted-foreground">
                  Help improve our dialect database
                </p>
              </div>
            </div>
            {profile && (
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={() => navigate("/profile")}>
                  <UserIcon className="h-4 w-4 mr-2" />
                  Profile
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/leaderboard")}>
                  <Trophy className="h-4 w-4 mr-2" />
                  Leaderboard
                </Button>
                <div className="flex items-center gap-2 ml-2">
                  <Award className="h-5 w-5 text-accent" />
                  <span className="font-bold">{profile.points} pts</span>
                  <Badge>Level {profile.level}</Badge>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {!showForm ? (
          <Button onClick={() => setShowForm(true)} className="mb-6 w-full md:w-auto">
            <Plus className="mr-2 h-4 w-4" />
            Submit New Phrase
          </Button>
        ) : (
          <Card className="mb-6 shadow-card gradient-card border-border/50">
            <CardHeader>
              <CardTitle>Submit a New Phrase</CardTitle>
              <CardDescription>
                Share dialectal expressions to help others learn
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phrase">Phrase/Expression</Label>
                  <Input
                    id="phrase"
                    value={newPhrase.phrase}
                    onChange={(e) =>
                      setNewPhrase({ ...newPhrase, phrase: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="translation">Translation</Label>
                  <Textarea
                    id="translation"
                    value={newPhrase.translation}
                    onChange={(e) =>
                      setNewPhrase({ ...newPhrase, translation: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="language">Language Code</Label>
                    <Input
                      id="language"
                      value={newPhrase.language_code}
                      onChange={(e) =>
                        setNewPhrase({ ...newPhrase, language_code: e.target.value })
                      }
                      placeholder="en, es, fr..."
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dialect">Dialect</Label>
                    <Input
                      id="dialect"
                      value={newPhrase.dialect}
                      onChange={(e) =>
                        setNewPhrase({ ...newPhrase, dialect: e.target.value })
                      }
                      placeholder="Regional dialect"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={newPhrase.category}
                      onChange={(e) =>
                        setNewPhrase({ ...newPhrase, category: e.target.value })
                      }
                      placeholder="greeting, slang..."
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button type="submit">Submit</Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="h-5 w-5" />
            <span>{phrases.length} community contributions</span>
          </div>

          {phrases.map((phrase) => (
            <Card
              key={phrase.id}
              className="shadow-card gradient-card border-border/50 hover:shadow-glow transition-all"
            >
              <CardContent className="p-6">
                <div className="flex gap-4">
                  <div className="flex flex-col items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleVote(phrase.id, "up")}
                    >
                      <ThumbsUp className="h-5 w-5" />
                    </Button>
                    <span className="font-bold text-lg">{phrase.vote_count}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleVote(phrase.id, "down")}
                    >
                      <ThumbsDown className="h-5 w-5" />
                    </Button>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-xl font-bold">{phrase.phrase}</h3>
                      {phrase.verified && (
                        <Badge className="bg-secondary">Verified</Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground mb-3">{phrase.translation}</p>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">{phrase.language_code}</Badge>
                      {phrase.dialect && <Badge variant="outline">{phrase.dialect}</Badge>}
                      {phrase.category && <Badge variant="outline">{phrase.category}</Badge>}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Community;
