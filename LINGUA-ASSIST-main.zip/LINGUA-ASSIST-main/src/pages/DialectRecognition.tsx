import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useDialectRecognition } from "@/hooks/use-dialect-recognition";
import { DialectSelector } from "@/components/DialectSelector";
import { ArrowLeft, Mic, MicOff, Upload, Loader2, Copy, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

const DialectRecognition = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [recognizedText, setRecognizedText] = useState("");
  const [copied, setCopied] = useState(false);
  
  const {
    selectedDialect,
    changeDialect,
    availableDialects,
    startRecording,
    stopRecording,
    isRecording,
    isProcessing,
    lastResult,
    error,
    recognizeFromFile,
  } = useDialectRecognition();

  useEffect(() => {
    if (lastResult?.text) {
      setRecognizedText(lastResult.text);
      toast({
        title: "Recognition Complete",
        description: `Recognized in ${selectedDialect.name}`,
      });
    }
  }, [lastResult, selectedDialect, toast]);

  useEffect(() => {
    if (error) {
      toast({
        title: "Recognition Error",
        description: error,
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const text = await recognizeFromFile(file);
      if (text) {
        setRecognizedText(text);
      }
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(recognizedText);
    setCopied(true);
    toast({
      title: "Copied!",
      description: "Text copied to clipboard",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Dialect Recognition</h1>
              <p className="text-sm text-muted-foreground">
                Recognize regional dialects with AI4Bharat
              </p>
            </div>
            <Badge variant="secondary" className="hidden sm:flex">
              {availableDialects.length} Dialects
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Dialect Selector */}
        <Card className="mb-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Select Dialect
              <Badge variant="outline" className="text-xs">
                Step 1
              </Badge>
            </CardTitle>
            <CardDescription>
              Choose the dialect you want to recognize from {availableDialects.length} options
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <DialectSelector
                selectedDialect={selectedDialect}
                onDialectChange={changeDialect}
                availableDialects={availableDialects}
              />
              <div className="flex-1">
                <div className="text-lg font-semibold">{selectedDialect.name}</div>
                <div className="text-sm text-muted-foreground">
                  {selectedDialect.nativeName}
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                  <span>{selectedDialect.region}</span>
                  <span>•</span>
                  <span>{(selectedDialect.speakers / 1000000).toFixed(0)}M speakers</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recording */}
        <Card className="mb-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Record or Upload Audio
              <Badge variant="outline" className="text-xs">
                Step 2
              </Badge>
            </CardTitle>
            <CardDescription>
              Speak in your selected dialect or upload an audio file
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-6">
              {/* Record Button */}
              <div className="w-full max-w-md">
                <Button
                  size="lg"
                  variant={isRecording ? "destructive" : "default"}
                  onClick={isRecording ? stopRecording : startRecording}
                  disabled={isProcessing}
                  className="w-full h-16 text-lg"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                      Processing Audio...
                    </>
                  ) : isRecording ? (
                    <>
                      <MicOff className="mr-2 h-6 w-6" />
                      Stop Recording
                    </>
                  ) : (
                    <>
                      <Mic className="mr-2 h-6 w-6" />
                      Start Recording
                    </>
                  )}
                </Button>

                {isRecording && (
                  <div className="mt-3 flex items-center justify-center gap-2">
                    <Badge variant="destructive" className="animate-pulse">
                      🔴 Recording...
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      Speak clearly in {selectedDialect.name}
                    </span>
                  </div>
                )}
              </div>

              {/* Divider */}
              <div className="flex items-center gap-4 w-full max-w-md">
                <div className="flex-1 h-px bg-border" />
                <span className="text-sm text-muted-foreground">or</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              {/* Upload Button */}
              <div className="w-full max-w-md">
                <label htmlFor="audio-upload" className="cursor-pointer">
                  <Button 
                    variant="outline" 
                    className="w-full h-16 text-lg" 
                    asChild
                    disabled={isProcessing}
                  >
                    <span>
                      <Upload className="mr-2 h-6 w-6" />
                      Upload Audio File
                    </span>
                  </Button>
                </label>
                <input
                  id="audio-upload"
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                  disabled={isProcessing}
                />
                <p className="mt-2 text-xs text-center text-muted-foreground">
                  Supports MP3, WAV, M4A, and other audio formats
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {recognizedText && (
          <Card className="mb-6 shadow-card gradient-card border-border/50 animate-in fade-in slide-in-from-bottom-4">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  Recognition Result
                  <Badge variant="outline" className="text-xs">
                    Step 3
                  </Badge>
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={copyToClipboard}
                  className="gap-2"
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              </CardTitle>
              <CardDescription>
                Recognized text in {selectedDialect.name}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-6 bg-primary/10 border-2 border-primary/20 rounded-lg">
                  <p className="text-xl font-medium leading-relaxed">
                    {recognizedText}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <Badge variant="secondary">{selectedDialect.name}</Badge>
                  <Badge variant="outline">{selectedDialect.nativeName}</Badge>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{selectedDialect.region}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Supported Dialects */}
          <Card className="shadow-card gradient-card border-border/50">
            <CardHeader>
              <CardTitle>Supported Dialects</CardTitle>
              <CardDescription>
                {availableDialects.length} dialects across 9 languages
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {['Tamil', 'Hindi', 'Telugu', 'Bengali', 'Marathi'].map((lang) => {
                  const count = availableDialects.filter(d => d.language === lang).length;
                  return (
                    <div key={lang} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{lang}</span>
                      <Badge variant="outline">{count} dialect{count > 1 ? 's' : ''}</Badge>
                    </div>
                  );
                })}
                <div className="pt-2 border-t">
                  <span className="text-xs text-muted-foreground">
                    + Gujarati, Kannada, Malayalam, Punjabi, Odia
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card className="shadow-card gradient-card border-border/50">
            <CardHeader>
              <CardTitle>How It Works</CardTitle>
              <CardDescription>
                Powered by AI4Bharat models
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                    1
                  </div>
                  <div>
                    <p className="text-sm font-medium">Select Dialect</p>
                    <p className="text-xs text-muted-foreground">
                      Choose from 22 regional dialects
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                    2
                  </div>
                  <div>
                    <p className="text-sm font-medium">Record or Upload</p>
                    <p className="text-xs text-muted-foreground">
                      Speak or upload audio file
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                    3
                  </div>
                  <div>
                    <p className="text-sm font-medium">Get Results</p>
                    <p className="text-xs text-muted-foreground">
                      AI recognizes and transcribes
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tips */}
        <Card className="mt-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle>Tips for Better Recognition</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 gap-3 text-sm">
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Speak clearly and at normal pace</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Reduce background noise</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Use good quality microphone</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-primary">✓</span>
                <span>Select correct dialect variant</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DialectRecognition;
