import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Trophy, Medal, Award, TrendingUp, Crown } from "lucide-react";

interface LeaderboardEntry {
  id: string;
  username: string;
  points: number;
  level: number;
  contributions: number;
  verified_phrases: number;
  rank: number;
}

const Leaderboard = () => {
  const [topByPoints, setTopByPoints] = useState<LeaderboardEntry[]>([]);
  const [topByContributions, setTopByContributions] = useState<LeaderboardEntry[]>([]);
  const [topByVerified, setTopByVerified] = useState<LeaderboardEntry[]>([]);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userRank, setUserRank] = useState<LeaderboardEntry | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = async () => {
    try {
      setLoading(true);

      // Get current user
      const { data: { session } } = await supabase.auth.getSession();
      setCurrentUser(session?.user);

      // Load top users by points
      const { data: pointsData, error: pointsError } = await supabase
        .from("profiles")
        .select("id, username, points, level, contributions, verified_phrases")
        .order("points", { ascending: false })
        .limit(50);

      if (pointsError) throw pointsError;
      setTopByPoints(pointsData?.map((user, index) => ({ ...user, rank: index + 1 })) || []);

      // Load top users by contributions
      const { data: contributionsData, error: contributionsError } = await supabase
        .from("profiles")
        .select("id, username, points, level, contributions, verified_phrases")
        .order("contributions", { ascending: false })
        .limit(50);

      if (contributionsError) throw contributionsError;
      setTopByContributions(contributionsData?.map((user, index) => ({ ...user, rank: index + 1 })) || []);

      // Load top users by verified phrases
      const { data: verifiedData, error: verifiedError } = await supabase
        .from("profiles")
        .select("id, username, points, level, contributions, verified_phrases")
        .order("verified_phrases", { ascending: false })
        .limit(50);

      if (verifiedError) throw verifiedError;
      setTopByVerified(verifiedData?.map((user, index) => ({ ...user, rank: index + 1 })) || []);

      // Get current user's rank
      if (session?.user) {
        const { data: userData, error: userError } = await supabase
          .from("profiles")
          .select("id, username, points, level, contributions, verified_phrases")
          .eq("id", session.user.id)
          .single();

        if (!userError && userData) {
          // Calculate rank based on points
          const { count } = await supabase
            .from("profiles")
            .select("*", { count: "exact", head: true })
            .gt("points", userData.points);

          setUserRank({ ...userData, rank: (count || 0) + 1 });
        }
      }
    } catch (error: any) {
      toast({
        title: "Error loading leaderboard",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Medal className="h-6 w-6 text-amber-600" />;
      default:
        return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankBadgeVariant = (rank: number): "default" | "secondary" | "destructive" | "outline" => {
    if (rank === 1) return "default";
    if (rank <= 3) return "secondary";
    if (rank <= 10) return "outline";
    return "outline";
  };

  const LeaderboardTable = ({ data, metric }: { data: LeaderboardEntry[]; metric: "points" | "contributions" | "verified_phrases" }) => {
    const getMetricValue = (entry: LeaderboardEntry) => {
      switch (metric) {
        case "points":
          return entry.points;
        case "contributions":
          return entry.contributions;
        case "verified_phrases":
          return entry.verified_phrases;
      }
    };

    const getMetricLabel = () => {
      switch (metric) {
        case "points":
          return "Points";
        case "contributions":
          return "Contributions";
        case "verified_phrases":
          return "Verified";
      }
    };

    return (
      <div className="space-y-3">
        {data.map((entry) => (
          <Card
            key={entry.id}
            className={`shadow-card border-border/50 transition-all hover:shadow-glow ${
              entry.id === currentUser?.id ? "gradient-card ring-2 ring-primary" : ""
            }`}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                {/* Rank */}
                <div className="flex-shrink-0 w-12 flex items-center justify-center">
                  {getRankIcon(entry.rank)}
                </div>

                {/* Avatar */}
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="gradient-accent">
                    {entry.username?.charAt(0).toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>

                {/* User Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold truncate">
                      {entry.username || "Anonymous"}
                    </h4>
                    {entry.id === currentUser?.id && (
                      <Badge variant="secondary" className="text-xs">You</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Award className="h-3 w-3" />
                      Level {entry.level}
                    </span>
                    <span>•</span>
                    <span className="font-semibold text-primary">
                      {getMetricValue(entry).toLocaleString()} {getMetricLabel()}
                    </span>
                  </div>
                </div>

                {/* Rank Badge */}
                <Badge variant={getRankBadgeVariant(entry.rank)} className="text-sm">
                  #{entry.rank}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading leaderboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Trophy className="h-6 w-6 text-primary" />
                Leaderboard
              </h1>
              <p className="text-sm text-muted-foreground">Top contributors and achievers</p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* User's Rank Card */}
        {userRank && (
          <Card className="mb-6 shadow-card gradient-card border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Your Ranking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-12 flex items-center justify-center">
                  {getRankIcon(userRank.rank)}
                </div>
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="gradient-accent">
                    {userRank.username?.charAt(0).toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-semibold">{userRank.username || "You"}</h4>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span>Rank #{userRank.rank}</span>
                    <span>•</span>
                    <span>{userRank.points} points</span>
                    <span>•</span>
                    <span>Level {userRank.level}</span>
                  </div>
                </div>
                <Button onClick={() => navigate("/profile")} size="sm">
                  View Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Leaderboard Tabs */}
        <Card className="shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Top Contributors
            </CardTitle>
            <CardDescription>See who's leading the community</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="points" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="points">
                  <Trophy className="h-4 w-4 mr-2" />
                  Points
                </TabsTrigger>
                <TabsTrigger value="contributions">
                  <Award className="h-4 w-4 mr-2" />
                  Contributions
                </TabsTrigger>
                <TabsTrigger value="verified">
                  <Medal className="h-4 w-4 mr-2" />
                  Verified
                </TabsTrigger>
              </TabsList>

              <TabsContent value="points" className="mt-0">
                <LeaderboardTable data={topByPoints} metric="points" />
              </TabsContent>

              <TabsContent value="contributions" className="mt-0">
                <LeaderboardTable data={topByContributions} metric="contributions" />
              </TabsContent>

              <TabsContent value="verified" className="mt-0">
                <LeaderboardTable data={topByVerified} metric="verified_phrases" />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <Card className="mt-6 shadow-card gradient-card border-border/50">
          <CardContent className="p-6 text-center">
            <Trophy className="h-12 w-12 mx-auto mb-3 text-primary" />
            <h3 className="text-xl font-bold mb-2">Climb the Ranks!</h3>
            <p className="text-muted-foreground mb-4">
              Contribute phrases, verify translations, and earn points to reach the top
            </p>
            <Button onClick={() => navigate("/community")} size="lg">
              Start Contributing
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Leaderboard;
