import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe, MessageSquare, Users, Award, Languages, Accessibility } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="gradient-hero min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-6xl mx-auto text-center">
          <Globe className="w-20 h-20 mx-auto mb-6 text-white animate-float" />
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white">
            AI for Everyone
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto">
            Breaking language barriers with inclusive AI technology. Supporting multiple dialects, 
            regional languages, and accessibility features for all.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => navigate("/auth")}
              className="text-lg px-8 py-6 shadow-glow"
            >
              Get Started
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/dialect")}
              className="text-lg px-8 py-6 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
            >
              Try Dialect Recognition
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/community")}
              className="text-lg px-8 py-6 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
            >
              Explore Community
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 text-gradient">
            Powerful Features
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <MessageSquare className="w-12 h-12 mb-4 text-primary" />
                <CardTitle>Multi-Modal Input</CardTitle>
                <CardDescription>
                  Communicate via voice, text, or gestures - choose what works best for you
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <Languages className="w-12 h-12 mb-4 text-secondary" />
                <CardTitle>Dialect Support</CardTitle>
                <CardDescription>
                  Support for regional languages, tribal dialects, and local expressions
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <Users className="w-12 h-12 mb-4 text-accent" />
                <CardTitle>Community Driven</CardTitle>
                <CardDescription>
                  Help improve accuracy by contributing and verifying phrases
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <Award className="w-12 h-12 mb-4 text-primary" />
                <CardTitle>Gamification</CardTitle>
                <CardDescription>
                  Earn points, badges, and levels as you contribute to the community
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <Accessibility className="w-12 h-12 mb-4 text-secondary" />
                <CardTitle>Accessibility First</CardTitle>
                <CardDescription>
                  Designed for users with visual, hearing, or speech impairments
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="shadow-card gradient-card border-border/50">
              <CardHeader>
                <Globe className="w-12 h-12 mb-4 text-accent" />
                <CardTitle>Real-Time Translation</CardTitle>
                <CardDescription>
                  Instant translation between languages and dialects powered by AI
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 gradient-hero">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">
            Join Our Global Community
          </h2>
          <p className="text-xl mb-8 text-white/90">
            Be part of building a more inclusive AI that works for everyone, everywhere.
          </p>
          <Button
            size="lg"
            onClick={() => navigate("/auth")}
            className="text-lg px-8 py-6 bg-white text-primary hover:bg-white/90"
          >
            Start Your Journey
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Index;
