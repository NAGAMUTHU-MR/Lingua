# Dialect Support Implementation Guide

## 🎯 Problem: Regional Dialect Support

Your current implementation uses browser-based Speech APIs which only support **standard/formal language versions**. For regional dialects like:
- **Tamil**: Kongu Tamil, Chennai Tamil, Madurai Tamil
- **Hindi**: Bhojpuri, Haryanvi, Rajasthani
- **Other languages**: Similar regional variations

You need specialized models.

---

## 💡 Recommended Solution: AI4Bharat Models

### Why AI4Bharat?
✅ **Free & Open Source**
✅ **Indian Language Focus** - Built specifically for Indian languages
✅ **Dialect Support** - Handles regional variations
✅ **Pre-trained** - No need to train from scratch
✅ **Active Development** - IIT Madras backed

### What AI4Bharat Offers

**1. IndicWav2Vec** (Speech Recognition)
- Supports 9 Indian languages
- Handles dialectal variations
- Better than standard models for Indian accents

**2. IndicTTS** (Text-to-Speech)
- Natural-sounding voices
- Multiple language support
- Dialect-aware synthesis

**3. IndicTrans** (Translation)
- Between Indian languages
- Preserves dialectal context

---

## 🚀 Implementation Plan

### Phase 1: Integrate AI4Bharat (Week 1-2)

#### Step 1: Install Dependencies

```bash
npm install @huggingface/inference
```

#### Step 2: Create Dialect Recognition Hook

Create `src/hooks/use-dialect-recognition.ts`:

```typescript
import { useState, useCallback } from 'react';
import { HfInference } from '@huggingface/inference';

interface DialectOption {
  code: string;
  name: string;
  language: string;
  model: string;
}

const DIALECT_MODELS: DialectOption[] = [
  {
    code: 'ta-kongu',
    name: 'Kongu Tamil',
    language: 'Tamil',
    model: 'ai4bharat/indicwav2vec-tamil'
  },
  {
    code: 'ta-chennai',
    name: 'Chennai Tamil',
    language: 'Tamil',
    model: 'ai4bharat/indicwav2vec-tamil'
  },
  {
    code: 'ta-madurai',
    name: 'Madurai Tamil',
    language: 'Tamil',
    model: 'ai4bharat/indicwav2vec-tamil'
  },
  {
    code: 'hi-bhojpuri',
    name: 'Bhojpuri',
    language: 'Hindi',
    model: 'ai4bharat/indicwav2vec-hindi'
  },
  // Add more dialects
];

export const useDialectRecognition = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedDialect, setSelectedDialect] = useState<DialectOption>(DIALECT_MODELS[0]);
  const [error, setError] = useState<string | null>(null);

  const recognizeDialect = useCallback(async (audioBlob: Blob) => {
    setIsProcessing(true);
    setError(null);

    try {
      // Use Hugging Face Inference API
      const hf = new HfInference(process.env.VITE_HUGGINGFACE_API_KEY);
      
      const result = await hf.automaticSpeechRecognition({
        model: selectedDialect.model,
        data: audioBlob
      });

      setIsProcessing(false);
      return result.text;
    } catch (err) {
      console.error('Dialect recognition error:', err);
      setError('Failed to recognize dialect');
      setIsProcessing(false);
      return null;
    }
  }, [selectedDialect]);

  return {
    isProcessing,
    selectedDialect,
    setSelectedDialect,
    availableDialects: DIALECT_MODELS,
    recognizeDialect,
    error
  };
};
```

#### Step 3: Create Dialect Selector Component

Create `src/components/DialectSelector.tsx`:

```typescript
import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

interface DialectOption {
  code: string;
  name: string;
  language: string;
  model: string;
}

interface DialectSelectorProps {
  selectedDialect: DialectOption;
  onDialectChange: (dialect: DialectOption) => void;
  availableDialects: DialectOption[];
}

export const DialectSelector = ({
  selectedDialect,
  onDialectChange,
  availableDialects,
}: DialectSelectorProps) => {
  // Group dialects by language
  const groupedDialects = availableDialects.reduce((acc, dialect) => {
    if (!acc[dialect.language]) {
      acc[dialect.language] = [];
    }
    acc[dialect.language].push(dialect);
    return acc;
  }, {} as Record<string, DialectOption[]>);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Languages className="h-4 w-4" />
          <span className="hidden sm:inline">{selectedDialect.name}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64 max-h-96 overflow-y-auto">
        <DropdownMenuLabel>Select Dialect</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {Object.entries(groupedDialects).map(([language, dialects]) => (
          <div key={language}>
            <DropdownMenuLabel className="text-xs text-muted-foreground">
              {language}
            </DropdownMenuLabel>
            {dialects.map((dialect) => (
              <DropdownMenuItem
                key={dialect.code}
                onClick={() => onDialectChange(dialect)}
                className="flex items-center justify-between"
              >
                <span>{dialect.name}</span>
                {selectedDialect.code === dialect.code && (
                  <Badge variant="secondary" className="ml-2">Active</Badge>
                )}
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
          </div>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
```

#### Step 4: Integrate into Chat Page

Update `src/pages/Chat.tsx`:

```typescript
// Add import
import { useDialectRecognition } from "@/hooks/use-dialect-recognition";
import { DialectSelector } from "@/components/DialectSelector";

// In Chat component
const {
  selectedDialect,
  setSelectedDialect,
  availableDialects,
  recognizeDialect,
  isProcessing: isRecognizingDialect
} = useDialectRecognition();

// Add dialect selector to header
<DialectSelector
  selectedDialect={selectedDialect}
  onDialectChange={setSelectedDialect}
  availableDialects={availableDialects}
/>

// Use dialect recognition instead of browser speech API
const handleDialectInput = async (audioBlob: Blob) => {
  const text = await recognizeDialect(audioBlob);
  if (text) {
    setInput(text);
  }
};
```

---

### Phase 2: Collect Dialect Data (Ongoing)

#### What You Need

**For Each Dialect:**
```
Minimum Dataset:
├── Audio Files: 10+ hours
├── Transcriptions: Text for each audio
├── Speakers: 20+ different people
├── Quality: Clear, minimal background noise
└── Format: WAV or FLAC (16kHz, mono)
```

#### Where to Get Data

**1. Crowdsource from Community**
```typescript
// Add to your app
interface DialectContribution {
  audio: Blob;
  text: string;
  dialect: string;
  speaker_id: string;
  verified: boolean;
}

// Let users contribute dialect samples
const contributeDialectSample = async (
  audio: Blob,
  text: string,
  dialect: string
) => {
  await supabase.from('dialect_samples').insert({
    audio_url: uploadedUrl,
    transcription: text,
    dialect_code: dialect,
    user_id: user.id,
    verified: false
  });
};
```

**2. Existing Datasets**
- **AI4Bharat Datasets**: https://ai4bharat.iitm.ac.in/datasets
- **OpenSLR**: http://www.openslr.org/
- **Common Voice**: https://commonvoice.mozilla.org/

**3. Partner with Local Organizations**
- Universities
- Cultural organizations
- Language preservation groups

#### Database Schema for Dialect Samples

```sql
-- Add to Supabase
CREATE TABLE dialect_samples (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  audio_url TEXT NOT NULL,
  transcription TEXT NOT NULL,
  dialect_code TEXT NOT NULL,
  language_code TEXT NOT NULL,
  duration_seconds FLOAT,
  verified BOOLEAN DEFAULT FALSE,
  verified_by UUID REFERENCES profiles(id),
  quality_score FLOAT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_dialect_samples_dialect ON dialect_samples(dialect_code);
CREATE INDEX idx_dialect_samples_verified ON dialect_samples(verified);
```

---

### Phase 3: Fine-tune Models (Month 2-3)

#### When You Have Enough Data

**Requirements:**
- 10+ hours of audio per dialect
- Good quality transcriptions
- Diverse speakers

#### Fine-tuning Process

**1. Set Up Environment**
```bash
# Create Python environment
python -m venv dialect_training
source dialect_training/bin/activate  # Linux/Mac
# or
dialect_training\Scripts\activate  # Windows

# Install dependencies
pip install transformers datasets torch torchaudio
```

**2. Prepare Dataset**
```python
# prepare_dataset.py
from datasets import Dataset, Audio
import pandas as pd

# Load your collected data
df = pd.read_csv('kongu_tamil_samples.csv')

# Create dataset
dataset = Dataset.from_pandas(df)
dataset = dataset.cast_column("audio", Audio(sampling_rate=16000))

# Split train/test
dataset = dataset.train_test_split(test_size=0.1)

# Save
dataset.save_to_disk("kongu_tamil_dataset")
```

**3. Fine-tune Model**
```python
# fine_tune.py
from transformers import (
    Wav2Vec2ForCTC,
    Wav2Vec2Processor,
    Trainer,
    TrainingArguments
)
from datasets import load_from_disk

# Load base model
model_name = "ai4bharat/indicwav2vec-tamil"
processor = Wav2Vec2Processor.from_pretrained(model_name)
model = Wav2Vec2ForCTC.from_pretrained(model_name)

# Load your dataset
dataset = load_from_disk("kongu_tamil_dataset")

# Training arguments
training_args = TrainingArguments(
    output_dir="./kongu_tamil_model",
    num_train_epochs=30,
    per_device_train_batch_size=8,
    gradient_accumulation_steps=2,
    learning_rate=1e-4,
    warmup_steps=500,
    save_steps=500,
    eval_steps=500,
    logging_steps=100,
    save_total_limit=2,
)

# Train
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["test"],
)

trainer.train()

# Save fine-tuned model
model.save_pretrained("./kongu_tamil_model_final")
processor.save_pretrained("./kongu_tamil_model_final")
```

**4. Deploy Fine-tuned Model**
```bash
# Upload to Hugging Face Hub
huggingface-cli login
huggingface-cli upload your-username/kongu-tamil-model ./kongu_tamil_model_final

# Update your app to use new model
# In use-dialect-recognition.ts:
model: 'your-username/kongu-tamil-model'
```

---

## 📊 Comparison: Options

| Approach | Time | Cost | Accuracy | Maintenance |
|----------|------|------|----------|-------------|
| **AI4Bharat (Pre-trained)** | 1-2 weeks | Free | Good (70-80%) | Low |
| **Fine-tune AI4Bharat** | 2-3 months | Low ($100-500) | Better (85-95%) | Medium |
| **Google/Azure APIs** | 1 week | High (ongoing) | Good (75-85%) | Low |
| **Train from Scratch** | 6-12 months | High ($5000+) | Best (90-98%) | High |

---

## 🎯 Recommended Roadmap

### **Month 1: Quick Start**
```
Week 1-2: Integrate AI4Bharat models
Week 3-4: Test with users, gather feedback
```

### **Month 2-3: Data Collection**
```
Week 5-8: Build dialect contribution feature
Week 9-12: Collect 10+ hours per dialect
```

### **Month 4-6: Fine-tuning**
```
Week 13-16: Prepare datasets
Week 17-20: Fine-tune models
Week 21-24: Deploy and test
```

---

## 💻 Complete Implementation Example

### Environment Variables

Add to `.env`:
```env
VITE_HUGGINGFACE_API_KEY=your_huggingface_api_key
```

### Package.json Updates

```json
{
  "dependencies": {
    "@huggingface/inference": "^2.6.4",
    // ... existing dependencies
  }
}
```

### Dialect Configuration

Create `src/config/dialects.ts`:

```typescript
export interface DialectConfig {
  code: string;
  name: string;
  nativeName: string;
  language: string;
  languageCode: string;
  model: string;
  region: string;
  speakers: number; // estimated speakers
}

export const SUPPORTED_DIALECTS: DialectConfig[] = [
  // Tamil Dialects
  {
    code: 'ta-kongu',
    name: 'Kongu Tamil',
    nativeName: 'கொங்கு தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Western Tamil Nadu',
    speakers: 10000000
  },
  {
    code: 'ta-chennai',
    name: 'Chennai Tamil',
    nativeName: 'சென்னை தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Chennai & surroundings',
    speakers: 15000000
  },
  {
    code: 'ta-madurai',
    name: 'Madurai Tamil',
    nativeName: 'மதுரை தமிழ்',
    language: 'Tamil',
    languageCode: 'ta',
    model: 'ai4bharat/indicwav2vec-tamil',
    region: 'Southern Tamil Nadu',
    speakers: 8000000
  },
  
  // Hindi Dialects
  {
    code: 'hi-bhojpuri',
    name: 'Bhojpuri',
    nativeName: 'भोजपुरी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'Bihar, UP, Jharkhand',
    speakers: 50000000
  },
  {
    code: 'hi-haryanvi',
    name: 'Haryanvi',
    nativeName: 'हरियाणवी',
    language: 'Hindi',
    languageCode: 'hi',
    model: 'ai4bharat/indicwav2vec-hindi',
    region: 'Haryana',
    speakers: 20000000
  },
  
  // Add more dialects as needed
];
```

---

## 🔧 Testing Your Dialect Implementation

### Test Script

Create `test_dialects.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Dialect Recognition Test</title>
</head>
<body>
    <h1>Test Dialect Recognition</h1>
    
    <select id="dialectSelect">
        <option value="ta-kongu">Kongu Tamil</option>
        <option value="ta-chennai">Chennai Tamil</option>
        <option value="ta-madurai">Madurai Tamil</option>
    </select>
    
    <button id="recordBtn">Record</button>
    <button id="stopBtn" disabled>Stop</button>
    
    <div id="result"></div>
    
    <script>
        // Test dialect recognition
        let mediaRecorder;
        let audioChunks = [];
        
        document.getElementById('recordBtn').onclick = async () => {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            
            mediaRecorder.ondataavailable = (e) => {
                audioChunks.push(e.data);
            };
            
            mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                const dialect = document.getElementById('dialectSelect').value;
                
                // Send to your API
                const formData = new FormData();
                formData.append('audio', audioBlob);
                formData.append('dialect', dialect);
                
                const response = await fetch('/api/recognize-dialect', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                document.getElementById('result').textContent = result.text;
                
                audioChunks = [];
            };
            
            mediaRecorder.start();
            document.getElementById('recordBtn').disabled = true;
            document.getElementById('stopBtn').disabled = false;
        };
        
        document.getElementById('stopBtn').onclick = () => {
            mediaRecorder.stop();
            document.getElementById('recordBtn').disabled = false;
            document.getElementById('stopBtn').disabled = true;
        };
    </script>
</body>
</html>
```

---

## 📚 Resources

### AI4Bharat
- **Website**: https://ai4bharat.iitm.ac.in/
- **Models**: https://huggingface.co/ai4bharat
- **Datasets**: https://ai4bharat.iitm.ac.in/datasets
- **Documentation**: https://indicnlp.ai4bharat.org/

### Hugging Face
- **Transformers**: https://huggingface.co/docs/transformers
- **Datasets**: https://huggingface.co/docs/datasets
- **Inference API**: https://huggingface.co/docs/api-inference

### Training Resources
- **Wav2Vec2 Fine-tuning**: https://huggingface.co/blog/fine-tune-wav2vec2-english
- **Speech Recognition Guide**: https://huggingface.co/docs/transformers/tasks/asr

---

## ✅ Summary

**Answer to Your Questions:**

1. **Should I train a model?**
   - **No, start with AI4Bharat pre-trained models**
   - Fine-tune later when you have data

2. **Is there an existing model?**
   - **Yes, AI4Bharat has models for Indian languages**
   - Supports dialectal variations

3. **Do I need dataset or whole model?**
   - **Start with pre-trained model (no dataset needed)**
   - Collect dataset later for fine-tuning
   - Dataset needed: 10+ hours per dialect for fine-tuning

**Recommended Path:**
```
Phase 1 (Now): Use AI4Bharat pre-trained ✅
Phase 2 (Month 2): Collect dialect data
Phase 3 (Month 4): Fine-tune for better accuracy
```

This approach gets you started quickly while building toward better accuracy over time!
