# Feature Usage Guide

## 🎯 Three Main Features - Complete Guide

This guide shows you exactly how to use the three key features that have been added to your project.

---

## 🔊 Feature 1: Text-to-Speech with Multiple Languages

### What It Does
- Speaks AI responses in 30+ different languages
- Each language has unique voice characteristics
- Supports major world languages and Indian regional languages

### How to Use It

#### Step 1: Start the Application
```bash
npm run dev
```
Open `http://localhost:5173` in your browser

#### Step 2: Navigate to Chat
- Click "Get Started" or go to `/chat`
- You'll see the chat interface

#### Step 3: Select a Language
1. Look at the **top right** of the chat header
2. Find the **language selector** button (shows current language like "English")
3. Click it to open the dropdown menu

#### Step 4: Try Different Languages

**Popular Languages:**
- **English** - Clear, multiple accents available
- **Español** (Spanish) - Expressive, clear pronunciation
- **Français** (French) - Melodic, European accent
- **Deutsch** (German) - Precise, clear
- **हिन्दी** (Hindi) - Natural Hindi pronunciation

**Indian Languages:**
- **বাংলা** (Bengali)
- **తెలుగు** (Telugu)
- **मराठी** (Marathi)
- **தமிழ்** (Tamil)
- **ગુજરાતી** (Gujarati)
- **ಕನ್ನಡ** (Kannada)
- **മലയാളം** (Malayalam)
- **ਪੰਜਾਬੀ** (Punjabi)
- **اردو** (Urdu)

**Other Languages:**
- 中文 (Chinese)
- 日本語 (Japanese)
- 한국어 (Korean)
- العربية (Arabic)
- Русский (Russian)
- Português (Portuguese)
- Italiano (Italian)
- And 10+ more!

#### Step 5: Test the Voice
1. Select a language from the dropdown
2. Type a message in the chat input
3. Press Enter or click Send
4. Wait for AI response
5. **Listen** - The response will be spoken in your selected language!

#### Step 6: Control TTS
- **Toggle On/Off**: Click the volume icon (🔊/🔇) next to language selector
- **Mute**: Click volume icon to disable TTS
- **Unmute**: Click again to enable TTS

### Voice Characteristics

| Language | Voice Quality | Best For |
|----------|--------------|----------|
| English | Multiple accents (US, UK, AU) | General use |
| Spanish | Expressive, clear | Latin content |
| Hindi | Natural, authentic | Indian content |
| Japanese | Soft, precise | Japanese text |
| Arabic | Right-to-left support | Arabic content |
| French | Melodic | European content |
| Chinese | Tonal accuracy | Chinese text |

### Pro Tips

**Tip 1: Test Multiple Voices**
- Some languages have multiple voice options
- Browser provides different voices per language
- Try switching languages to hear different voices

**Tip 2: Adjust Settings (Advanced)**
You can customize TTS in the code:
```typescript
// In src/hooks/use-text-to-speech.ts
setRate(0.8);   // Slower speech
setRate(1.5);   // Faster speech
setPitch(1.2);  // Higher pitch
setVolume(0.8); // Quieter
```

**Tip 3: Best Browsers**
- Chrome/Edge: Best voice selection
- Firefox: Good support
- Safari: Limited voices but works

---

## 👤 Feature 2: Profile with Achievements & Badges

### What It Does
- Tracks your contributions and progress
- Shows achievements you've unlocked
- Displays earned badges
- Visualizes progress toward goals

### How to Use It

#### Step 1: Access Your Profile

**Method 1: Direct URL**
```
http://localhost:5173/profile
```

**Method 2: From Community Page**
1. Go to `/community`
2. Click **"Profile"** button in the header
3. Your profile page opens

#### Step 2: View Your Stats

**Main Stats Card (Left Side):**
- **Avatar**: Your profile picture/initial
- **Username**: Your display name
- **Level**: Current level based on points
- **Level Progress Bar**: Shows progress to next level

**Four Stat Boxes:**
1. **Total Points** - All points earned
2. **Contributions** - Number of phrases submitted
3. **Verified** - Number of verified phrases
4. **Badges** - Number of badges earned

#### Step 3: Track Achievements

**Six Available Achievements:**

1. **🌟 First Contribution**
   - Requirement: Submit 1 phrase
   - Reward: 10 points
   - Progress: Shows 0/1 → 1/1

2. **🤝 Community Helper**
   - Requirement: Submit 10 phrases
   - Reward: 50 points
   - Progress: Shows X/10

3. **📚 Language Expert**
   - Requirement: Submit 50 phrases
   - Reward: 250 points
   - Progress: Shows X/50

4. **✅ Verification Master**
   - Requirement: Get 25 phrases verified
   - Reward: 200 points
   - Progress: Shows X/25

5. **💎 Point Collector**
   - Requirement: Earn 1000 points
   - Reward: Bonus badge
   - Progress: Shows X/1000

6. **⚡ Level 10**
   - Requirement: Reach level 10
   - Reward: Elite badge
   - Progress: Shows X/10

**Achievement Display:**
- ✅ Green = Completed
- ⏳ Gray = In Progress
- Progress bar shows percentage
- Each shows current/total count

#### Step 4: Earn Your First Achievement

**Quick Start Guide:**

1. **Go to Community Page**
   ```
   http://localhost:5173/community
   ```

2. **Click "Submit New Phrase"**

3. **Fill Out the Form:**
   ```
   Example 1 - Hindi Greeting:
   ─────────────────────────
   Phrase: नमस्ते
   Translation: Hello, greetings with respect
   Language Code: hi
   Dialect: Standard Hindi
   Category: greeting
   ```

   ```
   Example 2 - Spanish Slang:
   ─────────────────────────
   Phrase: ¿Qué tal?
   Translation: How are you? / What's up?
   Language Code: es
   Dialect: General Spanish
   Category: greeting
   ```

   ```
   Example 3 - Tamil Expression:
   ─────────────────────────
   Phrase: வணக்கம்
   Translation: Hello, welcome
   Language Code: ta
   Dialect: Standard Tamil
   Category: greeting
   ```

4. **Click Submit**

5. **Check Your Profile**
   - Go back to `/profile`
   - See "First Contribution" achievement unlocked! ✅
   - Your points increased by 10
   - Progress bar updated

#### Step 5: View Earned Badges

**Badges Section (Bottom Right):**
- Grid display of all earned badges
- Each badge shows:
  - Icon/Emoji
  - Badge name
  - Description
  - Earned date

**No Badges Yet?**
- Shows empty state with message
- Encourages you to contribute
- Links to community page

### Point System Explained

```
Action                          Points Earned
──────────────────────────────────────────────
Submit a phrase                 +10 points
Phrase gets verified            +20 points
Receive upvote on phrase        +5 points
Daily login                     +5 points
Complete achievement            +varies
```

### Leveling System

```
Formula: Level = Total Points ÷ 100

Examples:
─────────────────────────────────
0-99 points     → Level 0
100-199 points  → Level 1
500-599 points  → Level 5
1000-1099 points → Level 10
```

**Level Progress:**
- Progress bar shows % to next level
- Example: 150 points at Level 1
  - Need 200 for Level 2
  - Progress: 50/100 = 50%

### Strategy to Earn Achievements Fast

**Week 1 Plan:**
```
Day 1: Submit 1 phrase → First Contribution ✅
Day 2: Submit 2 phrases
Day 3: Submit 2 phrases
Day 4: Submit 2 phrases
Day 5: Submit 3 phrases
Result: 10 phrases → Community Helper ✅
```

**Month 1 Plan:**
```
Week 1: 10 phrases
Week 2: 10 phrases
Week 3: 15 phrases
Week 4: 15 phrases
Result: 50 phrases → Language Expert ✅
```

---

## 🏆 Feature 3: Leaderboard Competition

### What It Does
- Shows top contributors across three categories
- Displays your rank among all users
- Competitive rankings with special indicators
- Real-time position tracking

### How to Use It

#### Step 1: Access Leaderboard

**Method 1: Direct URL**
```
http://localhost:5173/leaderboard
```

**Method 2: From Community Page**
1. Go to `/community`
2. Click **"Leaderboard"** button in header
3. Leaderboard page opens

#### Step 2: View Your Rank

**Your Rank Card (Top of Page):**
- Shows your current rank
- Displays your avatar
- Shows your username
- Lists your level
- Shows total points
- Quick link to your profile

**Example:**
```
┌─────────────────────────────────────┐
│ Your Ranking                        │
├─────────────────────────────────────┤
│ #15  [Avatar] YourName              │
│      Rank #15 • 450 points • Level 4│
│                    [View Profile]   │
└─────────────────────────────────────┘
```

#### Step 3: Explore Three Categories

**Tab 1: 🏅 Points Leaderboard**
- **Metric**: Total points earned
- **Shows**: Users with most points
- **Good for**: Overall contribution ranking

**Tab 2: 📝 Contributions Leaderboard**
- **Metric**: Number of phrases submitted
- **Shows**: Most active contributors
- **Good for**: Quantity of contributions

**Tab 3: ✅ Verified Leaderboard**
- **Metric**: Number of verified phrases
- **Shows**: Highest quality contributors
- **Good for**: Quality of contributions

**Switch Between Tabs:**
- Click any tab to switch categories
- Each shows top 50 users
- Your position highlighted if in top 50

#### Step 4: Understand Rank Indicators

**Special Ranks:**
```
Rank #1:  👑 Gold Crown
Rank #2:  🥈 Silver Medal
Rank #3:  🥉 Bronze Medal
Rank #4-10: Colored badges
Rank #11+: Standard badges
```

**Leaderboard Entry Format:**
```
┌────────────────────────────────────┐
│ 👑 #1  [Avatar] TopContributor     │
│        Level 25 • 5,000 Points     │
└────────────────────────────────────┘
```

#### Step 5: Climb the Rankings

**Strategy for Points Leaderboard:**
```
Daily Actions:
─────────────────────────────────
✓ Submit 5 phrases          = 50 pts
✓ Get 2 verified            = 40 pts
✓ Vote on 10 phrases        = 50 pts
✓ Daily login               = 5 pts
─────────────────────────────────
Total per day               = 145 pts

Monthly projection          = 4,350 pts
Estimated rank              = Top 10
```

**Strategy for Contributions Leaderboard:**
```
Focus: Quantity
─────────────────────────────────
Daily goal: 5-10 phrases
Weekly goal: 50 phrases
Monthly goal: 200+ phrases

Tips:
- Cover multiple languages
- Various categories
- Different dialects
- Common expressions
```

**Strategy for Verified Leaderboard:**
```
Focus: Quality
─────────────────────────────────
Daily goal: 3-5 high-quality phrases
Weekly goal: 20 verified phrases
Monthly goal: 80+ verified

Tips:
- Accurate translations
- Clear context
- Proper formatting
- Native speaker quality
- Common useful phrases
```

### Competitive Features

**Your Entry Highlighting:**
- Your entry has special highlighting
- Shows "You" badge
- Different background color
- Easy to spot in list

**Top 50 Display:**
- Shows rank number
- User avatar
- Username
- Current level
- Category metric (points/contributions/verified)

**Real-time Updates:**
- Rankings update when you contribute
- Refresh page to see latest positions
- Your rank card always shows current position

### Gamification Elements

**Compete with Friends:**
1. Share your rank
2. Set weekly goals
3. Challenge others
4. Track progress together

**Personal Goals:**
```
Short-term (1 week):
- Climb 5 ranks
- Submit 20 phrases
- Get 5 verified

Medium-term (1 month):
- Reach top 20
- Submit 100 phrases
- Get 25 verified

Long-term (3 months):
- Reach top 10
- Submit 300 phrases
- Get 100 verified
```

---

## 🎮 Complete Workflow Example

### Scenario: New User Journey

**Day 1: Getting Started**
```
1. Open app → http://localhost:5173
2. Sign up/Login
3. Go to Chat → /chat
4. Click language selector
5. Choose Hindi (हिन्दी)
6. Send message: "Hello"
7. Listen to AI response in Hindi! 🔊
8. Go to Community → /community
9. Click "Submit New Phrase"
10. Submit first phrase:
    - Phrase: नमस्ते
    - Translation: Hello
    - Language: hi
11. Check Profile → /profile
12. See "First Contribution" unlocked! ✅
13. Check Leaderboard → /leaderboard
14. See your initial rank
```

**Week 1: Building Momentum**
```
Daily routine:
1. Try different TTS language
2. Submit 3-5 phrases
3. Vote on community phrases
4. Check leaderboard position
5. Track achievement progress

End of week:
- 10+ phrases submitted
- "Community Helper" unlocked ✅
- Climbed 20+ ranks
- Level 2-3 achieved
```

**Month 1: Becoming Expert**
```
Weekly routine:
1. Test all TTS languages
2. Submit 15-20 phrases
3. Focus on quality for verification
4. Compete in all 3 leaderboard categories

End of month:
- 50+ phrases submitted
- "Language Expert" unlocked ✅
- Top 50 in one category
- Level 5-7 achieved
- Multiple badges earned
```

---

## 🎯 Quick Reference

### TTS Languages Quick List
```
English, Spanish, French, German, Italian, Portuguese,
Russian, Japanese, Korean, Chinese, Arabic, Hindi,
Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada,
Malayalam, Punjabi, Urdu, Thai, Vietnamese, Indonesian,
Turkish, Polish, Dutch, Swedish, Hebrew, Greek, Ukrainian
```

### Achievement Checklist
```
□ First Contribution (1 phrase)
□ Community Helper (10 phrases)
□ Language Expert (50 phrases)
□ Verification Master (25 verified)
□ Point Collector (1000 points)
□ Level 10 (reach level 10)
```

### Leaderboard Categories
```
🏅 Points - Total points earned
📝 Contributions - Phrases submitted
✅ Verified - Verified phrases
```

---

## 🚀 Start Using These Features Now!

1. **Run the project:**
   ```bash
   npm run dev
   ```

2. **Test TTS:**
   - Go to `/chat`
   - Click language selector
   - Choose a language
   - Send a message

3. **Earn achievements:**
   - Go to `/community`
   - Submit a phrase
   - Check `/profile`

4. **Compete:**
   - Go to `/leaderboard`
   - See your rank
   - Set goals

---

**All features are ready to use right now!** 🎉

No additional setup needed - just run `npm run dev` and start exploring!
