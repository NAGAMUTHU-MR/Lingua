# Quick Reference Guide

## 🚀 New Features at a Glance

### Gesture Recognition 🤚
**Location**: Chat page → Hand icon  
**Gestures**: 👍 👎 ✌️ 👉 ✋ ✊  
**Requires**: Camera permission

### Text-to-Speech 🔊
**Location**: Chat page → Volume icon  
**Languages**: 30+ including Hindi, Bengali, Tamil, etc.  
**Toggle**: Click volume icon to enable/disable

### Profile Page 👤
**URL**: `/profile`  
**Shows**: Stats, achievements, badges, progress  
**Access**: Community page → Profile button

### Leaderboard 🏆
**URL**: `/leaderboard`  
**Categories**: Points, Contributions, Verified  
**Shows**: Top 50 users per category

### PWA Features 📱
**Install**: Chrome/Edge → Address bar → Install icon  
**Offline**: Works without internet after first load  
**Shortcuts**: Quick access to Chat, Community, Leaderboard

---

## ⌨️ Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Send message | `Enter` |
| New line | `Shift + Enter` |
| Focus input | `/` |

---

## 🎯 Quick Actions

### In Chat
- 🤚 **Enable Gestures**: Click hand icon
- 🔊 **Toggle TTS**: Click volume icon
- 🌐 **Change Language**: Click language selector
- 🎤 **Voice Input**: Click microphone icon

### In Community
- ➕ **Add Phrase**: Click "Submit New Phrase"
- 👍 **Vote Up**: Click thumbs up on phrase
- 👎 **Vote Down**: Click thumbs down on phrase
- 👤 **View Profile**: Click "Profile" button
- 🏆 **View Leaderboard**: Click "Leaderboard" button

---

## 🔧 Common Tasks

### Setup Gesture Recognition
1. Go to Chat page
2. Click hand icon
3. Allow camera access
4. Wait for model to load
5. Make gestures!

### Change TTS Language
1. Click language selector in Chat
2. Choose your language
3. TTS will use selected language
4. Test by sending a message

### View Your Stats
1. Go to Community page
2. Click "Profile" button
3. See your points, level, achievements
4. Track progress to next level

### Check Your Rank
1. Go to Community page
2. Click "Leaderboard" button
3. See your rank card at top
4. Browse top contributors

### Install as App
1. Open in Chrome/Edge
2. Look for install icon in address bar
3. Click "Install"
4. App opens in standalone window
5. Add to home screen on mobile

---

## 🎨 Gesture Guide

| Gesture | Symbol | Action | Confidence |
|---------|--------|--------|------------|
| Thumbs Up | 👍 | Approval | 80%+ |
| Thumbs Down | 👎 | Disapproval | 80%+ |
| Peace Sign | ✌️ | Peace | 85%+ |
| Pointing | 👉 | Indicate | 85%+ |
| Open Palm | ✋ | Hello/Stop | 90%+ |
| Fist | ✊ | Yes/Power | 90%+ |

**Tips**:
- Hold gesture for 1-2 seconds
- Keep hand in frame
- Good lighting helps
- Try different angles

---

## 🌍 Supported Languages

### Major Languages
English, Spanish, French, German, Italian, Portuguese, Russian, Japanese, Korean, Chinese, Arabic

### Indian Languages
Hindi (हिन्दी), Bengali (বাংলা), Telugu (తెలుగు), Marathi (मराठी), Tamil (தமிழ்), Gujarati (ગુજરાતી), Kannada (ಕನ್ನಡ), Malayalam (മലയാളം), Punjabi (ਪੰਜਾਬੀ), Urdu (اردو)

### Other Languages
Thai, Vietnamese, Indonesian, Turkish, Polish, Dutch, Swedish, Hebrew, Greek, Ukrainian

---

## 🏆 Achievements

| Achievement | Requirement | Points |
|-------------|-------------|--------|
| First Contribution | 1 phrase | 10 |
| Community Helper | 10 phrases | 50 |
| Language Expert | 50 phrases | 250 |
| Verification Master | 25 verified | 200 |
| Point Collector | 1000 points | - |
| Level 10 | Reach level 10 | - |

---

## 📱 Mobile Tips

### Best Experience
- Use Chrome or Safari
- Allow camera/microphone
- Install as PWA
- Use landscape for gestures
- Good lighting for camera

### Gestures on Mobile
- Hold phone steady
- Use front camera
- Position hand clearly
- Try different distances

---

## 🐛 Troubleshooting

### Gesture Recognition
**Not working?**
- Check camera permission
- Ensure good lighting
- Wait for model to load
- Try refreshing page

### Text-to-Speech
**No sound?**
- Check volume icon (not muted)
- Verify browser supports TTS
- Try different language
- Check system volume

### Profile/Leaderboard
**No data?**
- Ensure you're logged in
- Check internet connection
- Try refreshing page
- Verify Supabase connection

### PWA
**Can't install?**
- Use Chrome or Edge
- Ensure HTTPS (or localhost)
- Check for install icon
- Try desktop version

---

## 💡 Pro Tips

### Maximize Points
1. Submit quality phrases
2. Get phrases verified
3. Vote on community phrases
4. Use multiple languages
5. Contribute daily

### Better Gesture Recognition
1. Use good lighting
2. Solid background
3. Keep hand steady
4. Center in frame
5. Practice gestures

### Efficient TTS
1. Choose clear voices
2. Adjust speech rate
3. Use native language
4. Toggle when not needed
5. Test different voices

---

## 🔗 Quick Links

| Page | URL | Purpose |
|------|-----|---------|
| Home | `/` | Landing page |
| Auth | `/auth` | Login/Signup |
| Chat | `/chat` | AI conversation |
| Community | `/community` | Browse phrases |
| Profile | `/profile` | Your stats |
| Leaderboard | `/leaderboard` | Rankings |

---

## 📊 Stats Explained

### Points
Earned by:
- Submitting phrases (+10)
- Getting verified (+20)
- Receiving upvotes (+5)
- Daily login (+5)

### Level
- Based on total points
- 100 points per level
- Unlocks achievements
- Shows expertise

### Contributions
- Total phrases submitted
- Includes pending & verified
- Counts toward achievements
- Visible on leaderboard

### Verified
- Phrases approved by community
- Higher quality indicator
- Worth more points
- Separate leaderboard category

---

## 🎮 Gamification

### Earn Badges
- Complete achievements
- Reach milestones
- Contribute regularly
- Help community

### Climb Ranks
- Submit more phrases
- Get verified
- Earn points
- Level up

### Compete
- Check leaderboard
- Compare with friends
- Set personal goals
- Track progress

---

## 🔐 Privacy

### What We Access
- Camera (for gestures, optional)
- Microphone (for voice, optional)
- Location (never)
- Contacts (never)

### What We Store
- Your profile data
- Submitted phrases
- Vote history
- Achievement progress

### What We Don't Store
- Video/audio recordings
- Gesture data
- Speech data
- Personal files

---

## 📞 Need Help?

### Check First
1. This guide
2. FEATURES.md (detailed docs)
3. SETUP.md (installation)
4. Browser console (errors)

### Still Stuck?
- Review troubleshooting section
- Check browser compatibility
- Verify permissions
- Try different browser

---

## 🎯 Getting Started Checklist

- [ ] Install dependencies (`npm install`)
- [ ] Create icon files (optional)
- [ ] Run dev server (`npm run dev`)
- [ ] Allow camera permission
- [ ] Test gesture recognition
- [ ] Try text-to-speech
- [ ] View your profile
- [ ] Check leaderboard
- [ ] Install as PWA (optional)

---

## 🌟 Best Practices

### For Users
- Grant necessary permissions
- Use latest browser version
- Ensure stable internet
- Report bugs/issues
- Provide feedback

### For Developers
- Read full documentation
- Follow code style
- Test before committing
- Update dependencies
- Monitor performance

---

**Last Updated**: October 10, 2025  
**Version**: 1.0.0

---

**Quick Tip**: Bookmark this page for easy reference! 📌
