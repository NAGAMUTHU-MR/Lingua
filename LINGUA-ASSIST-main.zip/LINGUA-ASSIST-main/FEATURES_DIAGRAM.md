# Features Architecture Diagram

## 🎯 Three Main Features - Visual Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                     AI FOR EVERYONE APPLICATION                      │
└─────────────────────────────────────────────────────────────────────┘
                                  │
                    ┌─────────────┼─────────────┐
                    │             │             │
                    ▼             ▼             ▼
        ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
        │   FEATURE 1  │  │   FEATURE 2  │  │   FEATURE 3  │
        │     TTS      │  │   PROFILE    │  │ LEADERBOARD  │
        │  30+ LANGS   │  │ ACHIEVEMENTS │  │ 3 CATEGORIES │
        └──────────────┘  └──────────────┘  └──────────────┘
```

---

## 🔊 Feature 1: Text-to-Speech Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    CHAT PAGE (/chat)                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Header:  [🌐 Language Selector] [🔊 TTS Toggle]           │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  User: "Hello"                                        │ │
│  │  AI: "Hi! How can I help you?"  🔊 [Speaking...]     │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
        ┌─────────────────────────────────────┐
        │   useTextToSpeech() Hook            │
        ├─────────────────────────────────────┤
        │ • 30+ Languages                     │
        │ • Voice Selection                   │
        │ • Rate/Pitch/Volume Control         │
        │ • Browser Speech API                │
        └─────────────────────────────────────┘
                          │
                          ▼
        ┌─────────────────────────────────────┐
        │   Language Selector Component       │
        ├─────────────────────────────────────┤
        │ Popular:                            │
        │  • English                          │
        │  • Español                          │
        │  • Français                         │
        │  • Deutsch                          │
        │  • हिन्दी                            │
        │                                     │
        │ All Languages:                      │
        │  • 25+ more languages               │
        │  • Indian regional languages        │
        │  • Asian languages                  │
        │  • European languages               │
        └─────────────────────────────────────┘
```

### Language Flow

```
User Action          →  System Response
─────────────────────────────────────────────────────
Select Language      →  Update TTS language
Send Message         →  AI generates response
AI Response Ready    →  speak(response)
                     →  Audio plays in selected language
Toggle TTS Off       →  Stop speaking
Toggle TTS On        →  Resume speaking
```

---

## 👤 Feature 2: Profile & Achievements Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   PROFILE PAGE (/profile)                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────┐  ┌─────────────────────────────────┐ │
│  │  PROFILE CARD   │  │     ACHIEVEMENTS GRID           │ │
│  ├─────────────────┤  ├─────────────────────────────────┤ │
│  │ [Avatar]        │  │ ✅ First Contribution (1/1)     │ │
│  │ Username        │  │ ⏳ Community Helper (5/10)      │ │
│  │ Level 3         │  │ ⏳ Language Expert (5/50)       │ │
│  │ ████░░░░ 30%    │  │ ⏳ Verification Master (0/25)   │ │
│  │                 │  │ ⏳ Point Collector (350/1000)   │ │
│  │ 350 Points      │  │ ⏳ Level 10 (3/10)              │ │
│  │ 5 Contributions │  └─────────────────────────────────┘ │
│  │ 2 Verified      │                                      │
│  │ 1 Badge         │  ┌─────────────────────────────────┐ │
│  │                 │  │     EARNED BADGES               │ │
│  │ [Contribute]    │  ├─────────────────────────────────┤ │
│  └─────────────────┘  │ 🌟 First Contribution           │ │
│                       │    Earned: Oct 10, 2025         │ │
│                       └─────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Achievement System Flow

```
User Action              →  Points Earned  →  Achievement Progress
────────────────────────────────────────────────────────────────────
Submit 1st phrase        →  +10 points     →  First Contribution ✅
Submit 10 phrases        →  +100 points    →  Community Helper ✅
Submit 50 phrases        →  +500 points    →  Language Expert ✅
Get 25 verified          →  +500 points    →  Verification Master ✅
Reach 1000 points        →  Milestone      →  Point Collector ✅
Reach Level 10           →  Milestone      →  Level 10 ✅
```

### Points & Leveling System

```
┌──────────────────────────────────────────────────────────┐
│                    POINT SYSTEM                          │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Submit phrase          →  +10 points                   │
│  Phrase verified        →  +20 points                   │
│  Receive upvote         →  +5 points                    │
│  Daily login            →  +5 points                    │
│                                                          │
├──────────────────────────────────────────────────────────┤
│                   LEVELING FORMULA                       │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Level = Total Points ÷ 100                             │
│                                                          │
│  Examples:                                              │
│  • 0-99 points    = Level 0                             │
│  • 100-199 points = Level 1                             │
│  • 500-599 points = Level 5                             │
│  • 1000+ points   = Level 10+                           │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

## 🏆 Feature 3: Leaderboard Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                LEADERBOARD PAGE (/leaderboard)              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │              YOUR RANKING CARD                        │ │
│  ├───────────────────────────────────────────────────────┤ │
│  │  #15  [Avatar] YourName                               │ │
│  │       Rank #15 • 450 points • Level 4                 │ │
│  │                                    [View Profile]     │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  [🏅 Points] [📝 Contributions] [✅ Verified]         │ │
│  ├───────────────────────────────────────────────────────┤ │
│  │                                                       │ │
│  │  👑 #1   TopUser1        Level 25  •  5,000 Points   │ │
│  │  🥈 #2   TopUser2        Level 20  •  4,500 Points   │ │
│  │  🥉 #3   TopUser3        Level 18  •  4,000 Points   │ │
│  │  #4      User4           Level 15  •  3,500 Points   │ │
│  │  #5      User5           Level 14  •  3,200 Points   │ │
│  │  ...                                                  │ │
│  │  #15     YourName (You)  Level 4   •    450 Points   │ │
│  │  ...                                                  │ │
│  │  #50     User50          Level 2   •    150 Points   │ │
│  │                                                       │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Three Leaderboard Categories

```
┌──────────────────────────────────────────────────────────────┐
│                    CATEGORY 1: POINTS                        │
├──────────────────────────────────────────────────────────────┤
│  Metric: Total points earned                                 │
│  Ranking: Highest points first                               │
│  Best for: Overall contribution                              │
│                                                              │
│  Strategy:                                                   │
│  • Submit many phrases                                       │
│  • Get phrases verified                                      │
│  • Vote on community phrases                                 │
│  • Daily login streaks                                       │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                 CATEGORY 2: CONTRIBUTIONS                    │
├──────────────────────────────────────────────────────────────┤
│  Metric: Number of phrases submitted                         │
│  Ranking: Most phrases first                                 │
│  Best for: Active contributors                               │
│                                                              │
│  Strategy:                                                   │
│  • Focus on quantity                                         │
│  • Submit daily                                              │
│  • Cover multiple languages                                  │
│  • Various categories                                        │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                   CATEGORY 3: VERIFIED                       │
├──────────────────────────────────────────────────────────────┤
│  Metric: Number of verified phrases                          │
│  Ranking: Most verified first                                │
│  Best for: Quality contributors                              │
│                                                              │
│  Strategy:                                                   │
│  • Focus on quality                                          │
│  • Accurate translations                                     │
│  • Clear context                                             │
│  • Native-level phrases                                      │
└──────────────────────────────────────────────────────────────┘
```

### Rank Indicators

```
┌────────────────────────────────────────┐
│         RANK INDICATORS                │
├────────────────────────────────────────┤
│                                        │
│  Rank #1:  👑 Gold Crown               │
│  Rank #2:  🥈 Silver Medal             │
│  Rank #3:  🥉 Bronze Medal             │
│  Rank #4-10: 🏅 Colored Badges         │
│  Rank #11+: 🎖️ Standard Badges         │
│                                        │
│  Your Entry: Highlighted Background    │
│              "You" Badge               │
│                                        │
└────────────────────────────────────────┘
```

---

## 🔄 How Features Work Together

```
┌─────────────────────────────────────────────────────────────┐
│                   INTEGRATED WORKFLOW                       │
└─────────────────────────────────────────────────────────────┘

    User Opens App
         │
         ▼
    ┌─────────┐
    │  CHAT   │ ◄──── Feature 1: TTS with 30+ Languages
    └─────────┘
         │
         │ (User wants to contribute)
         │
         ▼
    ┌─────────────┐
    │  COMMUNITY  │
    └─────────────┘
         │
         │ (Submit phrases)
         │
         ▼
    ┌─────────────┐
    │   PROFILE   │ ◄──── Feature 2: Track Achievements
    └─────────────┘
         │
         │ (Check ranking)
         │
         ▼
    ┌─────────────┐
    │ LEADERBOARD │ ◄──── Feature 3: Compete with Others
    └─────────────┘
         │
         │ (Motivated to contribute more)
         │
         ▼
    Back to COMMUNITY
    (Cycle continues)
```

### Data Flow

```
┌──────────────────────────────────────────────────────────┐
│                      DATA FLOW                           │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  User Action          Database Update      UI Update    │
│  ────────────────────────────────────────────────────   │
│                                                          │
│  Submit phrase    →   dialect_phrases   →  +10 points   │
│                   →   profiles          →  +1 contrib   │
│                                         →  Profile ✓    │
│                                         →  Leaderboard ✓│
│                                                          │
│  Phrase verified  →   dialect_phrases   →  +20 points   │
│                   →   profiles          →  +1 verified  │
│                                         →  Achievement ✓│
│                                         →  Leaderboard ✓│
│                                                          │
│  Upvote phrase    →   phrase_votes      →  +5 points    │
│                   →   profiles          →  Profile ✓    │
│                                         →  Leaderboard ✓│
│                                                          │
└──────────────────────────────────────────────────────────┘
```

---

## 🎯 User Journey Map

```
┌─────────────────────────────────────────────────────────────┐
│                    NEW USER JOURNEY                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Day 1: Discovery                                           │
│  ├─ Open app                                                │
│  ├─ Try TTS in different languages ◄─── Feature 1          │
│  ├─ Submit first phrase                                     │
│  └─ Unlock "First Contribution" ◄────── Feature 2          │
│                                                             │
│  Week 1: Engagement                                         │
│  ├─ Submit 10 phrases                                       │
│  ├─ Unlock "Community Helper" ◄───────── Feature 2         │
│  ├─ Check leaderboard rank ◄──────────── Feature 3         │
│  └─ Climb to rank #50                                       │
│                                                             │
│  Month 1: Mastery                                           │
│  ├─ Submit 50 phrases                                       │
│  ├─ Unlock "Language Expert" ◄────────── Feature 2         │
│  ├─ Reach top 20 ◄───────────────────── Feature 3         │
│  ├─ Test all TTS languages ◄──────────── Feature 1         │
│  └─ Level 5+ achieved                                       │
│                                                             │
│  Month 3: Expert                                            │
│  ├─ 100+ phrases submitted                                  │
│  ├─ Multiple achievements unlocked ◄───── Feature 2        │
│  ├─ Top 10 in one category ◄──────────── Feature 3        │
│  └─ Community leader                                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 📊 Feature Metrics Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│                    METRICS OVERVIEW                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Feature 1: TTS                                             │
│  ├─ Languages Available: 30+                                │
│  ├─ Voices per Language: 1-10+                              │
│  ├─ Browser Support: 95%                                    │
│  └─ Usage: Every AI response                                │
│                                                             │
│  Feature 2: Profile                                         │
│  ├─ Achievements: 6 types                                   │
│  ├─ Badges: Unlimited                                       │
│  ├─ Levels: Unlimited                                       │
│  └─ Progress Tracking: Real-time                            │
│                                                             │
│  Feature 3: Leaderboard                                     │
│  ├─ Categories: 3                                           │
│  ├─ Display Limit: Top 50                                   │
│  ├─ Rank Indicators: 5 types                                │
│  └─ Update Frequency: On action                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start Diagram

```
START HERE
    │
    ▼
┌─────────────┐
│ npm install │
└─────────────┘
    │
    ▼
┌─────────────┐
│ npm run dev │
└─────────────┘
    │
    ▼
┌─────────────────────────────────────┐
│ Open http://localhost:5173          │
└─────────────────────────────────────┘
    │
    ├──────────────┬──────────────┬──────────────┐
    │              │              │              │
    ▼              ▼              ▼              ▼
┌────────┐   ┌──────────┐   ┌─────────┐   ┌────────────┐
│  CHAT  │   │COMMUNITY │   │ PROFILE │   │LEADERBOARD │
│        │   │          │   │         │   │            │
│ Try    │   │ Submit   │   │ Track   │   │ Compete    │
│ TTS    │   │ Phrases  │   │ Progress│   │ Rankings   │
│        │   │          │   │         │   │            │
│ 🔊     │   │ ✍️       │   │ 🏆      │   │ 📊         │
└────────┘   └──────────┘   └─────────┘   └────────────┘
```

---

**All three features are fully integrated and ready to use!** 🎉

Just run `npm run dev` and start exploring!
