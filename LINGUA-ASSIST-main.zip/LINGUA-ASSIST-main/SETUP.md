# Setup Guide for New Features

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

This will install all required packages including:
- TensorFlow.js and MediaPipe Hands for gesture recognition
- All existing dependencies

### 2. Configure PWA Icons

Create the following icon files in the `public/` directory:
- `icon-192.png` (192x192 pixels)
- `icon-512.png` (512x512 pixels)

You can use any logo or icon that represents your application. Tools like [Favicon Generator](https://realfavicongenerator.net/) can help create these.

**Temporary Solution**: You can use any PNG image and rename it, or the app will work without icons (they just won't display in the PWA install prompt).

### 3. Database Schema Updates (Optional)

The Profile and Leaderboard pages expect additional columns in the `profiles` table. If you want full functionality, add these to your Supabase schema:

```sql
-- Add columns to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS contributions INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS verified_phrases INTEGER DEFAULT 0;

-- Create badges table (optional)
CREATE TABLE IF NOT EXISTS badges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_badges table (optional)
CREATE TABLE IF NOT EXISTS user_badges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  badge_id UUID REFERENCES badges(id) ON DELETE CASCADE,
  earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, badge_id)
);
```

**Note**: The app will work without these tables, but badge functionality will be limited.

### 4. Run Development Server
```bash
npm run dev
```

The app will be available at `http://localhost:5173` (or another port if 5173 is in use).

---

## Feature Testing

### Test Gesture Recognition
1. Navigate to `/chat`
2. Click the hand icon in the header
3. Allow camera access when prompted
4. Wait for the model to load (first time only)
5. Make gestures in front of your camera:
   - Thumbs up
   - Thumbs down
   - Peace sign
   - Pointing
   - Open palm
   - Fist

### Test Text-to-Speech
1. Navigate to `/chat`
2. Click the language selector and choose a language
3. Ensure the volume icon shows as enabled (not muted)
4. Send a message to the AI
5. The response should be spoken aloud
6. Click the volume icon to toggle TTS on/off

### Test Profile Page
1. Navigate to `/profile` or click "Profile" in Community
2. View your stats, achievements, and badges
3. Check progress bars for each achievement

### Test Leaderboard
1. Navigate to `/leaderboard` or click "Leaderboard" in Community
2. Switch between Points, Contributions, and Verified tabs
3. Find your rank in the leaderboard

### Test PWA Features
1. Open the app in Chrome/Edge
2. Look for the install prompt in the address bar
3. Click "Install" to add to home screen
4. Open as standalone app
5. Test offline functionality (disconnect network)

---

## Browser Requirements

### Minimum Requirements
- **Chrome/Edge**: Version 90+
- **Firefox**: Version 88+
- **Safari**: Version 14+
- **Mobile**: iOS 14+ or Android 8+

### Required Features
- WebGL 2.0 (for TensorFlow.js)
- MediaDevices API (for camera access)
- Web Speech API (for TTS)
- Service Workers (for PWA)

### Check Compatibility
Open browser console and run:
```javascript
// Check WebGL
console.log('WebGL:', !!document.createElement('canvas').getContext('webgl2'));

// Check Camera
console.log('Camera:', 'mediaDevices' in navigator);

// Check Speech
console.log('Speech:', 'speechSynthesis' in window);

// Check Service Workers
console.log('SW:', 'serviceWorker' in navigator);
```

---

## Troubleshooting

### Gesture Recognition Not Working

**Issue**: Camera not accessible
- **Solution**: Grant camera permissions in browser settings
- **Chrome**: Settings → Privacy and security → Site Settings → Camera
- **Firefox**: Permissions → Camera → Allow

**Issue**: Model loading fails
- **Solution**: Check internet connection (model downloads from CDN)
- **Alternative**: Model is cached after first load

**Issue**: Poor gesture detection
- **Solution**: 
  - Ensure good lighting
  - Position hand clearly in frame
  - Keep hand steady for 1-2 seconds
  - Try different angles

### Text-to-Speech Not Working

**Issue**: No voices available
- **Solution**: 
  - Wait a few seconds for voices to load
  - Try a different browser
  - Check OS language settings

**Issue**: Wrong language spoken
- **Solution**: Select correct language from language selector

**Issue**: Speech cuts off
- **Solution**: Reduce speech rate in hook settings

### PWA Not Installing

**Issue**: No install prompt
- **Solution**:
  - Ensure HTTPS (or localhost)
  - Check manifest.json is accessible
  - Verify service worker registered
  - Try Chrome/Edge (best support)

**Issue**: Icons not showing
- **Solution**: Add icon files to `public/` directory

### Profile/Leaderboard Errors

**Issue**: Database errors
- **Solution**: Run the SQL schema updates (see step 3)

**Issue**: No data showing
- **Solution**: 
  - Ensure user is authenticated
  - Check Supabase connection
  - Verify table permissions

---

## Performance Optimization

### Gesture Recognition
- Model loads once and is cached
- Uses WebGL backend for GPU acceleration
- Processes at ~30 FPS on modern devices
- Can be disabled when not in use

### Text-to-Speech
- Uses native browser APIs (no external dependencies)
- Minimal performance impact
- Can be toggled off for better performance

### PWA
- Service worker caches assets
- Reduces network requests
- Improves load times
- Enables offline functionality

---

## Development Tips

### Hot Module Replacement
Vite provides HMR, so changes appear instantly without full reload.

### TypeScript
All new features are fully typed. Check types with:
```bash
npm run lint
```

### Testing Gestures Locally
Use your phone's camera for better mobility testing:
1. Find your local IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
2. Access app at `http://YOUR_IP:5173`
3. Allow camera access on mobile

### Debugging TTS
```typescript
// In browser console
const synth = window.speechSynthesis;
console.log(synth.getVoices()); // List available voices
```

---

## Production Deployment

### Build for Production
```bash
npm run build
```

### Preview Production Build
```bash
npm run preview
```

### Environment Variables
Ensure these are set in production:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

### HTTPS Required
PWA features (especially camera access) require HTTPS in production.

### CDN Considerations
TensorFlow.js models load from CDN. Ensure:
- CDN is accessible in your region
- No CORS issues
- Consider self-hosting models for better reliability

---

## Support & Resources

### Documentation
- [TensorFlow.js Docs](https://www.tensorflow.org/js)
- [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands)
- [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)
- [PWA Guide](https://web.dev/progressive-web-apps/)

### Community
- Check GitHub issues for known problems
- Submit bug reports with browser/OS info
- Share feature requests

---

## Next Steps

1. ✅ Install dependencies
2. ✅ Create icon files
3. ✅ Update database schema (optional)
4. ✅ Test all features
5. ✅ Deploy to production

**Happy coding! 🚀**
