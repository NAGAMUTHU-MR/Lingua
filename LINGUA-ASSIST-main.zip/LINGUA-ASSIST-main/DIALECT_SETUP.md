# Dialect Recognition Setup Guide

## ✅ Files Created

You now have three new files for dialect support:

1. ✅ `src/config/dialects.ts` - Dialect configuration
2. ✅ `src/hooks/use-dialect-recognition.ts` - Dialect recognition hook
3. ✅ `src/components/DialectSelector.tsx` - Dialect selector UI

---

## 🔑 Step 1: Get Hugging Face API Key

### Create Account
1. Go to https://huggingface.co/
2. Click "Sign Up" (top right)
3. Create free account

### Get API Key
1. After login, click your profile picture (top right)
2. Click "Settings"
3. Click "Access Tokens" in left sidebar
4. Click "New token"
5. Name it: "dialect-recognition"
6. Role: "read"
7. Click "Generate"
8. **Copy the token** (starts with `hf_...`)

### Add to .env File
Open `.env` file and add:
```env
VITE_HUGGINGFACE_API_KEY=hf_your_token_here
```

Replace `hf_your_token_here` with your actual token.

---

## 🎯 Step 2: Integrate into Chat Page

### Option A: Add Dialect Recognition to Existing Chat

Update `src/pages/Chat.tsx`:

```typescript
// Add imports at the top
import { useDialectRecognition } from "@/hooks/use-dialect-recognition";
import { DialectSelector } from "@/components/DialectSelector";

// Inside Chat component, add the hook
const {
  selectedDialect,
  changeDialect,
  availableDialects,
  startRecording,
  stopRecording,
  isRecording,
  isProcessing,
  lastResult,
  error: dialectError,
} = useDialectRecognition();

// Add dialect selector to header (around line 206, after LanguageSelector)
<DialectSelector
  selectedDialect={selectedDialect}
  onDialectChange={changeDialect}
  availableDialects={availableDialects}
/>

// Add dialect recording button (after the mic button)
<Button
  type="button"
  size="icon"
  variant={isRecording ? "destructive" : "outline"}
  onClick={isRecording ? stopRecording : startRecording}
  disabled={isProcessing}
  title="Dialect Recognition"
>
  {isRecording ? (
    <MicOff className="h-5 w-5" />
  ) : (
    <Mic className="h-5 w-5 text-primary" />
  )}
</Button>

// Handle dialect recognition result
useEffect(() => {
  if (lastResult?.text) {
    setInput(lastResult.text);
  }
}, [lastResult]);

// Show dialect error if any
{dialectError && (
  <div className="text-sm text-destructive">
    {dialectError}
  </div>
)}
```

---

## 🎨 Step 3: Create Dedicated Dialect Page (Optional)

Create `src/pages/DialectRecognition.tsx`:

```typescript
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useDialectRecognition } from "@/hooks/use-dialect-recognition";
import { DialectSelector } from "@/components/DialectSelector";
import { ArrowLeft, Mic, MicOff, Upload, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const DialectRecognition = () => {
  const navigate = useNavigate();
  const [recognizedText, setRecognizedText] = useState("");
  
  const {
    selectedDialect,
    changeDialect,
    availableDialects,
    startRecording,
    stopRecording,
    isRecording,
    isProcessing,
    lastResult,
    error,
    recognizeFromFile,
  } = useDialectRecognition();

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const text = await recognizeFromFile(file);
      if (text) {
        setRecognizedText(text);
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Dialect Recognition</h1>
              <p className="text-sm text-muted-foreground">
                Recognize regional dialects with AI
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Dialect Selector */}
        <Card className="mb-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle>Select Dialect</CardTitle>
            <CardDescription>
              Choose the dialect you want to recognize
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <DialectSelector
                selectedDialect={selectedDialect}
                onDialectChange={changeDialect}
                availableDialects={availableDialects}
              />
              <div className="flex-1">
                <div className="text-sm font-medium">{selectedDialect.name}</div>
                <div className="text-xs text-muted-foreground">
                  {selectedDialect.region} • {(selectedDialect.speakers / 1000000).toFixed(0)}M speakers
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recording */}
        <Card className="mb-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle>Record Audio</CardTitle>
            <CardDescription>
              Speak in your selected dialect
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-4">
              <Button
                size="lg"
                variant={isRecording ? "destructive" : "default"}
                onClick={isRecording ? stopRecording : startRecording}
                disabled={isProcessing}
                className="w-full max-w-xs"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Processing...
                  </>
                ) : isRecording ? (
                  <>
                    <MicOff className="mr-2 h-5 w-5" />
                    Stop Recording
                  </>
                ) : (
                  <>
                    <Mic className="mr-2 h-5 w-5" />
                    Start Recording
                  </>
                )}
              </Button>

              {isRecording && (
                <Badge variant="destructive" className="animate-pulse">
                  Recording...
                </Badge>
              )}

              <div className="text-center text-sm text-muted-foreground">
                or
              </div>

              <div className="w-full max-w-xs">
                <label htmlFor="audio-upload">
                  <Button variant="outline" className="w-full" asChild>
                    <span>
                      <Upload className="mr-2 h-5 w-5" />
                      Upload Audio File
                    </span>
                  </Button>
                </label>
                <input
                  id="audio-upload"
                  type="file"
                  accept="audio/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {(lastResult || recognizedText || error) && (
          <Card className="shadow-card gradient-card border-border/50">
            <CardHeader>
              <CardTitle>Recognition Result</CardTitle>
            </CardHeader>
            <CardContent>
              {error ? (
                <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-sm text-destructive">{error}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-primary/10 border border-primary/20 rounded-md">
                    <p className="text-lg font-medium">
                      {lastResult?.text || recognizedText}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Badge variant="outline">{selectedDialect.name}</Badge>
                    <span>•</span>
                    <span>{selectedDialect.region}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Info */}
        <Card className="mt-6 shadow-card gradient-card border-border/50">
          <CardHeader>
            <CardTitle>Supported Dialects</CardTitle>
            <CardDescription>
              {availableDialects.length} dialects across multiple languages
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {availableDialects.slice(0, 12).map((dialect) => (
                <Badge key={dialect.code} variant="outline">
                  {dialect.name}
                </Badge>
              ))}
              {availableDialects.length > 12 && (
                <Badge variant="secondary">
                  +{availableDialects.length - 12} more
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DialectRecognition;
```

Then add route in `src/App.tsx`:

```typescript
import DialectRecognition from "./pages/DialectRecognition";

// Add route
<Route path="/dialect" element={<DialectRecognition />} />
```

---

## 🧪 Step 4: Test Dialect Recognition

### Test 1: Basic Setup
```bash
# 1. Restart dev server
npm run dev

# 2. Check console for errors
# Should NOT see "Hugging Face API key not found"
```

### Test 2: Record Audio
1. Go to `/chat` or `/dialect`
2. Click dialect selector
3. Choose "Kongu Tamil" or any dialect
4. Click record button
5. Speak in that dialect
6. Click stop
7. See recognized text!

### Test 3: Upload Audio
1. Prepare an audio file (WAV, MP3, etc.)
2. Click "Upload Audio File"
3. Select your file
4. See recognized text!

---

## 📊 Supported Dialects

### Tamil (4 dialects)
- Standard Tamil (தமிழ்)
- Kongu Tamil (கொங்கு தமிழ்)
- Chennai Tamil (சென்னை தமிழ்)
- Madurai Tamil (மதுரை தமிழ்)

### Hindi (4 dialects)
- Standard Hindi (हिन्दी)
- Bhojpuri (भोजपुरी)
- Haryanvi (हरियाणवी)
- Rajasthani (राजस्थानी)

### Other Languages (11 languages)
- Telugu, Bengali, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Odia

**Total: 22 dialects across 9 Indian languages**

---

## 🔧 Customization

### Add More Dialects

Edit `src/config/dialects.ts`:

```typescript
{
  code: 'ta-tirunelveli',
  name: 'Tirunelveli Tamil',
  nativeName: 'திருநெல்வேலி தமிழ்',
  language: 'Tamil',
  languageCode: 'ta',
  model: 'ai4bharat/indicwav2vec-tamil',
  region: 'Tirunelveli district',
  speakers: 3000000
},
```

### Change Model

To use a different model:

```typescript
model: 'your-username/your-custom-model'
```

### Adjust Audio Settings

In `use-dialect-recognition.ts`, modify:

```typescript
audio: {
  channelCount: 1,
  sampleRate: 16000,  // Change sample rate
  echoCancellation: true,
  noiseSuppression: true,
}
```

---

## 🐛 Troubleshooting

### Error: "Hugging Face API key not found"
**Solution:** Add `VITE_HUGGINGFACE_API_KEY` to `.env` file

### Error: "Failed to access microphone"
**Solution:** Grant microphone permissions in browser settings

### Error: "Rate limit exceeded"
**Solution:** 
- Free tier has limits
- Wait a few minutes
- Or upgrade to Pro plan

### Error: "Model not available"
**Solution:**
- Check internet connection
- Model might be loading
- Try different dialect

### Poor Recognition Accuracy
**Solutions:**
- Speak clearly
- Reduce background noise
- Use good quality microphone
- Try different dialect variant

---

## 💰 Hugging Face API Limits

### Free Tier
- 30,000 requests/month
- Rate limit: 100 requests/hour
- Good for testing and small apps

### Pro Tier ($9/month)
- 1,000,000 requests/month
- Higher rate limits
- Better for production

---

## 📈 Next Steps

### Phase 1: Test (Week 1)
- [x] Create files
- [ ] Add API key
- [ ] Test with Tamil dialects
- [ ] Test with Hindi dialects
- [ ] Verify accuracy

### Phase 2: Integrate (Week 2)
- [ ] Add to Chat page
- [ ] Create dedicated page
- [ ] Add to navigation
- [ ] User testing

### Phase 3: Improve (Month 2+)
- [ ] Collect user feedback
- [ ] Gather dialect samples
- [ ] Fine-tune models
- [ ] Add more dialects

---

## 🎉 You're Ready!

All dialect recognition files are created and ready to use!

**Next steps:**
1. Get Hugging Face API key
2. Add to `.env` file
3. Restart dev server
4. Test dialect recognition!

**Questions?** Check `DIALECT_IMPLEMENTATION_GUIDE.md` for detailed information.
